'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Moon, Sun, Menu, X, Sparkles } from 'lucide-react';
import { useTheme } from '@/contexts/theme-provider';
import { useState, useEffect } from 'react';

const navLinks = [
    { href: '/', label: 'Home' },
    { href: '/products', label: 'Products' },
    { href: '/services', label: 'Services' },
    { href: '/about', label: 'About' },
    { href: '/contact', label: 'Contact' },
    { href: '/dashboard', label: 'Dashboard' },
];

export default function Navbar() {
    const pathname = usePathname();
    const { theme, toggleTheme } = useTheme();
    const [isOpen, setIsOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);
    const { scrollY } = useScroll();
    const opacity = useTransform(scrollY, [0, 100], [0.85, 1]);
    const blur = useTransform(scrollY, [0, 100], [16, 24]);

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 20);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <motion.header
            style={{ opacity }}
            className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-7xl transition-all duration-500 ${isScrolled ? 'glass-vibrant shadow-2xl shadow-primary/20' : 'glass-vibrant'
                } rounded-full px-6 py-4`}
        >
            <nav className="flex items-center justify-between">
                <Link href="/" className="flex items-center gap-2 group">
                    <motion.div
                        animate={{
                            rotate: [0, 5, -5, 0],
                            scale: [1, 1.05, 1]
                        }}
                        transition={{
                            duration: 3,
                            repeat: Infinity,
                            ease: "easeInOut"
                        }}
                    >
                        <Sparkles className="w-6 h-6 text-primary group-hover:text-accent transition-colors" />
                    </motion.div>
                    <span className="text-2xl font-bold gradient-text group-hover:gradient-text-vibrant transition-all">
                        Skyline Corps
                    </span>
                </Link>

                {/* Desktop Navigation */}
                <ul className="hidden md:flex items-center gap-8">
                    {navLinks.map((link) => (
                        <li key={link.href}>
                            <Link
                                href={link.href}
                                className={`relative text-sm font-medium transition-all duration-300 ${pathname === link.href
                                        ? 'text-primary font-bold scale-110'
                                        : 'text-foreground/70 hover:text-primary hover:scale-105'
                                    }`}
                            >
                                {link.label}
                                {pathname === link.href && (
                                    <motion.div
                                        layoutId="navbar-indicator"
                                        className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-600 rounded-full"
                                        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                                    />
                                )}
                                <motion.div
                                    className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-cyan-500/0 via-purple-600/50 to-pink-600/0 rounded-full opacity-0 hover:opacity-100 transition-opacity"
                                />
                            </Link>
                        </li>
                    ))}
                </ul>

                <div className="flex items-center gap-4">
                    <motion.button
                        onClick={toggleTheme}
                        className="p-2.5 rounded-full glass hover:glass-vibrant hover:neon-glow transition-all duration-300 group"
                        aria-label="Toggle theme"
                        whileHover={{ scale: 1.1, rotate: 15 }}
                        whileTap={{ scale: 0.95, rotate: -15 }}
                    >
                        {theme === 'dark' ? (
                            <Sun className="w-5 h-5 text-yellow-400 group-hover:rotate-90 transition-transform duration-500" />
                        ) : (
                            <Moon className="w-5 h-5 text-purple-600 group-hover:-rotate-90 transition-transform duration-500" />
                        )}
                    </motion.button>

                    <motion.button
                        onClick={() => setIsOpen(!isOpen)}
                        className="md:hidden p-2.5 rounded-full glass hover:glass-vibrant transition-all duration-300"
                        aria-label="Toggle menu"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}
                    >
                        {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                    </motion.button>
                </div>
            </nav>

            {/* Mobile Menu */}
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0, height: 0, y: -20 }}
                    animate={{ opacity: 1, height: 'auto', y: 0 }}
                    exit={{ opacity: 0, height: 0, y: -20 }}
                    transition={{ duration: 0.3, ease: 'easeOut' }}
                    className="md:hidden mt-4 pt-4 border-t border-foreground/10"
                >
                    <ul className="flex flex-col gap-4">
                        {navLinks.map((link, index) => (
                            <motion.li
                                key={link.href}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: index * 0.05 }}
                            >
                                <Link
                                    href={link.href}
                                    onClick={() => setIsOpen(false)}
                                    className={`block text-sm font-medium transition-all duration-300 px-4 py-2 rounded-lg ${pathname === link.href
                                            ? 'text-primary bg-primary/10 font-bold'
                                            : 'text-foreground/70 hover:text-primary hover:bg-primary/5'
                                        }`}
                                >
                                    {link.label}
                                </Link>
                            </motion.li>
                        ))}
                    </ul>
                </motion.div>
            )}
        </motion.header>
    );
}
