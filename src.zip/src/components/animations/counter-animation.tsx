'use client';

import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

interface CounterAnimationProps {
    target: number;
    duration?: number;
    suffix?: string;
    prefix?: string;
    className?: string;
    decimals?: number;
}

export default function CounterAnimation({
    target,
    duration = 2000,
    suffix = '',
    prefix = '',
    className = '',
    decimals = 0
}: CounterAnimationProps) {
    const [count, setCount] = useState(0);
    const [hasAnimated, setHasAnimated] = useState(false);

    useEffect(() => {
        if (hasAnimated) return;

        const steps = 60;
        const increment = target / steps;
        const stepDuration = duration / steps;
        let current = 0;

        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                setCount(target);
                setHasAnimated(true);
                clearInterval(timer);
            } else {
                setCount(current);
            }
        }, stepDuration);

        return () => clearInterval(timer);
    }, [target, duration, hasAnimated]);

    const displayValue = decimals > 0
        ? count.toFixed(decimals)
        : Math.floor(count).toLocaleString();

    return (
        <motion.span
            className={`inline-block ${className}`}
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
        >
            {prefix}{displayValue}{suffix}
        </motion.span>
    );
}
