'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

interface CursorTrailProps {
    color?: string;
    size?: number;
    trailLength?: number;
}

export default function CursorTrail({
    color = '#06B6D4',
    size = 20,
    trailLength = 10
}: CursorTrailProps) {
    const [trail, setTrail] = useState<{ x: number; y: number; id: number }[]>([]);
    const [idCounter, setIdCounter] = useState(0);

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            const newPoint = { x: e.clientX, y: e.clientY, id: idCounter };
            setIdCounter(prev => prev + 1);

            setTrail(prev => {
                const updated = [...prev, newPoint];
                return updated.slice(-trailLength);
            });
        };

        window.addEventListener('mousemove', handleMouseMove);
        return () => window.removeEventListener('mousemove', handleMouseMove);
    }, [idCounter, trailLength]);

    return (
        <div className="fixed inset-0 pointer-events-none" style={{ zIndex: 9999 }}>
            {trail.map((point, index) => (
                <motion.div
                    key={point.id}
                    className="absolute rounded-full"
                    style={{
                        left: point.x,
                        top: point.y,
                        width: size,
                        height: size,
                        backgroundColor: color,
                        boxShadow: `0 0 ${size}px ${color}`,
                    }}
                    initial={{ scale: 1, opacity: 0.8 }}
                    animate={{ scale: 0, opacity: 0 }}
                    transition={{ duration: 0.6 }}
                />
            ))}
        </div>
    );
}
