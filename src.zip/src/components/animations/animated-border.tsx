'use client';

import { ReactNode } from 'react';

interface AnimatedBorderProps {
    children: ReactNode;
    className?: string;
    borderWidth?: number;
    speed?: 'slow' | 'medium' | 'fast';
    colors?: string[];
}

const speedMap = {
    slow: 'animate-spin-slow',
    medium: 'animate-rotate-slow',
    fast: 'animate-[spin_10s_linear_infinite]',
};

export default function AnimatedBorder({
    children,
    className = '',
    borderWidth = 2,
    speed = 'medium',
    colors = ['#00f0ff', '#bf40ff', '#ff10f0'],
}: AnimatedBorderProps) {
    return (
        <div className={`relative ${className}`}>
            <div
                className={`absolute inset-0 ${speedMap[speed]} rounded-[inherit]`}
                style={{
                    background: `conic-gradient(from 0deg, ${colors.join(', ')}, ${colors[0]})`,
                    padding: `${borderWidth}px`,
                    WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
                    WebkitMaskComposite: 'xor',
                    maskComposite: 'exclude',
                }}
            />
            <div className="relative z-10">{children}</div>
        </div>
    );
}
