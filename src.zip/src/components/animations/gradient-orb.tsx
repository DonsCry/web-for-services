'use client';

import { motion } from 'framer-motion';

interface GradientOrbProps {
    size?: 'sm' | 'md' | 'lg' | 'xl';
    colors?: string[];
    className?: string;
    delay?: number;
}

const sizeMap = {
    sm: 'w-32 h-32 md:w-48 md:h-48',
    md: 'w-48 h-48 md:w-64 md:h-64',
    lg: 'w-64 h-64 md:w-96 md:h-96',
    xl: 'w-96 h-96 md:w-[32rem] md:h-[32rem]',
};

export default function GradientOrb({
    size = 'md',
    colors = ['#00f0ff', '#bf40ff'],
    className = '',
    delay = 0
}: GradientOrbProps) {
    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 0.4, scale: 1 }}
            transition={{ duration: 1.5, delay }}
            className={`${sizeMap[size]} rounded-full ${className}`}
            style={{
                background: `linear-gradient(135deg, ${colors.join(', ')})`,
                filter: 'blur(80px)',
            }}
        />
    );
}
