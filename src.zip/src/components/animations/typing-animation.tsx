'use client';

import { useEffect, useState } from 'react';

interface TypingAnimationProps {
    texts: string[];
    typingSpeed?: number;
    deletingSpeed?: number;
    delayBetween?: number;
    className?: string;
    cursorColor?: string;
}

export default function TypingAnimation({
    texts,
    typingSpeed = 100,
    deletingSpeed = 50,
    delayBetween = 2000,
    className = '',
    cursorColor = 'cyan'
}: TypingAnimationProps) {
    const [displayText, setDisplayText] = useState('');
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isDeleting, setIsDeleting] = useState(false);
    const [showCursor, setShowCursor] = useState(true);

    useEffect(() => {
        const currentText = texts[currentIndex];

        const timeout = setTimeout(() => {
            if (!isDeleting) {
                if (displayText.length < currentText.length) {
                    setDisplayText(currentText.slice(0, displayText.length + 1));
                } else {
                    setTimeout(() => setIsDeleting(true), delayBetween);
                }
            } else {
                if (displayText.length > 0) {
                    setDisplayText(displayText.slice(0, -1));
                } else {
                    setIsDeleting(false);
                    setCurrentIndex((currentIndex + 1) % texts.length);
                }
            }
        }, isDeleting ? deletingSpeed : typingSpeed);

        return () => clearTimeout(timeout);
    }, [displayText, isDeleting, currentIndex, texts, typingSpeed, deletingSpeed, delayBetween]);

    useEffect(() => {
        const cursorInterval = setInterval(() => {
            setShowCursor(prev => !prev);
        }, 500);

        return () => clearInterval(cursorInterval);
    }, []);

    return (
        <span className={className}>
            {displayText}
            <span
                className={`inline-block w-0.5 h-[1em] ml-1 ${showCursor ? 'opacity-100' : 'opacity-0'}`}
                style={{
                    backgroundColor: cursorColor,
                    boxShadow: `0 0 10px ${cursorColor}`
                }}
            />
        </span>
    );
}
