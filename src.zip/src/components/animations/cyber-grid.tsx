'use client';

import { useEffect, useRef } from 'react';

interface CyberGridProps {
    className?: string;
    gridSize?: number;
    color?: string;
    glowIntensity?: number;
}

export default function CyberGrid({
    className = '',
    gridSize = 50,
    color = '#06B6D4',
    glowIntensity = 0.5
}: CyberGridProps) {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        let animationId: number;
        let offset = 0;

        function draw() {
            if (!ctx || !canvas) return;

            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // Draw grid
            ctx.strokeStyle = color;
            ctx.lineWidth = 1;
            ctx.globalAlpha = 0.2;

            // Vertical lines
            for (let x = 0; x < canvas.width; x += gridSize) {
                ctx.beginPath();
                ctx.moveTo(x + offset, 0);
                ctx.lineTo(x + offset, canvas.height);
                ctx.stroke();
            }

            // Horizontal lines
            for (let y = 0; y < canvas.height; y += gridSize) {
                ctx.beginPath();
                ctx.moveTo(0, y + offset);
                ctx.lineTo(canvas.width, y + offset);
                ctx.stroke();
            }

            // Draw glowing intersections
            ctx.globalAlpha = glowIntensity;
            ctx.fillStyle = color;
            ctx.shadowBlur = 10;
            ctx.shadowColor = color;

            for (let x = 0; x < canvas.width; x += gridSize) {
                for (let y = 0; y < canvas.height; y += gridSize) {
                    if (Math.random() > 0.95) {
                        ctx.beginPath();
                        ctx.arc(x + offset, y + offset, 2, 0, Math.PI * 2);
                        ctx.fill();
                    }
                }
            }

            offset += 0.5;
            if (offset > gridSize) offset = 0;

            animationId = requestAnimationFrame(draw);
        }

        draw();

        const handleResize = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };

        window.addEventListener('resize', handleResize);

        return () => {
            cancelAnimationFrame(animationId);
            window.removeEventListener('resize', handleResize);
        };
    }, [gridSize, color, glowIntensity]);

    return (
        <canvas
            ref={canvasRef}
            className={`fixed inset-0 pointer-events-none ${className}`}
            style={{ zIndex: 0 }}
        />
    );
}
