import mongoose, { Schema, models } from 'mongoose';

export interface IFavorite {
    _id: string;
    userId: string;
    productId: string;
    createdAt: Date;
}

const favoriteSchema = new Schema<IFavorite>(
    {
        userId: {
            type: String,
            required: true,
        },
        productId: {
            type: String,
            required: true,
        },
    },
    {
        timestamps: true,
    }
);

favoriteSchema.index({ userId: 1, productId: 1 }, { unique: true });

const Favorite = models.Favorite || mongoose.model<IFavorite>('Favorite', favoriteSchema);

export default Favorite;
