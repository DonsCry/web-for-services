'use client';

import { useState, useEffect } from 'react';
import { Search, Heart, X, Send, Calendar, DollarSign, User, Mail, Phone, FileText, Sparkles, Code } from 'lucide-react';
import ScrollReveal from '@/components/animations/scroll-reveal';
import HolographicCard from '@/components/animations/holographic-card';
import GlitchText from '@/components/animations/glitch-text';
import CyberGrid from '@/components/animations/cyber-grid';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import productsData from '@/data/products.json';
import { Product } from '@/types';

const categories = ['All', 'Mobile', 'Web', 'Design', 'Security', 'Infrastructure', 'Blockchain', 'Game Dev', 'Emerging Tech', 'Data'];

interface BookingForm {
    name: string;
    email: string;
    phone: string;
    company: string;
    projectDetails: string;
    budget: string;
    timeline: string;
}

export default function ProductsPage() {
    const [products] = useState<Product[]>(productsData as Product[]);
    const [filteredProducts, setFilteredProducts] = useState<Product[]>(products);
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [searchQuery, setSearchQuery] = useState('');
    const [favorites, setFavorites] = useState<Set<string>>(new Set());
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
    const [showBookingModal, setShowBookingModal] = useState(false);
    const [bookingForm, setBookingForm] = useState<BookingForm>({
        name: '',
        email: '',
        phone: '',
        company: '',
        projectDetails: '',
        budget: '',
        timeline: ''
    });

    useEffect(() => {
        let result = products;

        if (selectedCategory !== 'All') {
            result = result.filter(p => p.category === selectedCategory);
        }

        if (searchQuery) {
            result = result.filter(p =>
                p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                p.description.toLowerCase().includes(searchQuery.toLowerCase())
            );
        }

        setFilteredProducts(result);
    }, [selectedCategory, searchQuery, products]);

    const toggleFavorite = (productId: string) => {
        setFavorites(prev => {
            const newFavorites = new Set(prev);
            if (newFavorites.has(productId)) {
                newFavorites.delete(productId);
                toast.success('Removed from favorites');
            } else {
                newFavorites.add(productId);
                toast.success('Added to favorites');
            }
            return newFavorites;
        });
    };

    const handleBookingSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        // Validation
        if (!bookingForm.name || !bookingForm.email || !bookingForm.phone) {
            toast.error('Please fill in all required fields');
            return;
        }

        // Simulate booking submission
        toast.success(
            `Booking request sent! We'll contact you at ${bookingForm.email} within 24 hours.`,
            { duration: 5000 }
        );

        // Reset form and close modal
        setBookingForm({
            name: '',
            email: '',
            phone: '',
            company: '',
            projectDetails: '',
            budget: '',
            timeline: ''
        });
        setShowBookingModal(false);
        setSelectedProduct(null);
    };

    const openBookingModal = (product: Product) => {
        setSelectedProduct(product);
        setShowBookingModal(true);
    };

    return (
        <div className="relative min-h-screen">
            {/* Cyber Grid Background */}
            <CyberGrid className="opacity-10" />

            <div className="max-w-7xl mx-auto px-4 py-12 relative z-10">
                <ScrollReveal>
                    {/* Tech Badge */}
                    <motion.div
                        className="flex justify-center mb-6"
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: 'spring' }}
                    >
                        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full tech-card cyber-glow">
                            <Code className="w-4 h-4 text-cyan-400 animate-pulse" />
                            <span className="text-sm font-semibold tech-gradient-text">Professional Services</span>
                            <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
                        </div>
                    </motion.div>

                    {/* Main Title with Glitch */}
                    <h1 className="text-5xl md:text-7xl font-bold mb-6 text-center">
                        <GlitchText intensity="medium">
                            <span className="tech-gradient-text">Our Services</span>
                        </GlitchText>
                    </h1>
                    <p className="text-center text-foreground/70 mb-12 max-w-2xl mx-auto text-lg">
                        Comprehensive <span className="text-cyan-400 font-semibold">digital solutions</span> tailored to elevate your business
                    </p>
                </ScrollReveal>

                {/* Search and Filter with Tech Styling */}
                <div className="mb-12 space-y-6">
                    <ScrollReveal delay={0.1}>
                        <div className="relative max-w-xl mx-auto">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-cyan-400" />
                            <input
                                type="text"
                                placeholder="Search services..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="w-full pl-12 pr-4 py-4 rounded-full tech-card cyber-glow focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all"
                            />
                        </div>
                    </ScrollReveal>

                    <ScrollReveal delay={0.2}>
                        <div className="flex flex-wrap gap-3 justify-center">
                            {categories.map((category) => (
                                <motion.button
                                    key={category}
                                    onClick={() => setSelectedCategory(category)}
                                    className={`px-6 py-2 rounded-full transition-all text-sm font-medium ${selectedCategory === category
                                        ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white shadow-lg shadow-cyan-500/25 neon-pulse'
                                        : 'tech-card hover:cyber-glow hover:scale-105'
                                        }`}
                                    whileHover={{ scale: 1.05 }}
                                    whileTap={{ scale: 0.95 }}
                                >
                                    {category}
                                </motion.button>
                            ))}
                        </div>
                    </ScrollReveal>
                </div>

                {/* Products Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                    {filteredProducts.map((product, index) => (
                        <ScrollReveal key={product.id} delay={index * 0.05}>
                            <HolographicCard className="cursor-pointer h-full flex flex-col">
                                <div className="relative overflow-hidden h-56 scan-line">
                                    <img
                                        src={product.image}
                                        alt={product.name}
                                        className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                                        onClick={() => setSelectedProduct(product)}
                                    />
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />

                                    {/* Favorite Button */}
                                    <motion.button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            toggleFavorite(product.id);
                                        }}
                                        className="absolute top-4 right-4 p-2 rounded-full tech-card cyber-glow z-10"
                                        whileHover={{ scale: 1.1 }}
                                        whileTap={{ scale: 0.9 }}
                                    >
                                        <Heart
                                            className={`w-5 h-5 ${favorites.has(product.id)
                                                    ? 'fill-pink-500 text-pink-500 drop-shadow-[0_0_10px_rgba(236,72,153,0.8)]'
                                                    : 'text-white'
                                                }`}
                                        />
                                    </motion.button>

                                    {/* Featured Badge */}
                                    {product.featured && (
                                        <motion.div
                                            className="absolute top-4 left-4 px-3 py-1 bg-gradient-to-r from-cyan-500 to-purple-600 backdrop-blur-md text-white rounded-full text-xs font-bold uppercase tracking-wider shadow-lg neon-pulse"
                                            initial={{ scale: 0 }}
                                            animate={{ scale: 1 }}
                                            transition={{ delay: 0.2 }}
                                        >
                                            ⭐ Popular
                                        </motion.div>
                                    )}

                                    {/* Category Badge */}
                                    <div className="absolute bottom-4 left-4 right-4">
                                        <span className="px-3 py-1 rounded-full tech-card text-xs font-semibold text-cyan-400 border border-cyan-500/30">
                                            {product.category}
                                        </span>
                                    </div>
                                </div>

                                <div className="p-6 flex flex-col flex-grow">
                                    <h3 className="text-xl font-bold mb-2 tech-gradient-text line-clamp-1">{product.name}</h3>
                                    <p className="text-foreground/70 text-sm mb-4 line-clamp-2 flex-grow">{product.description}</p>

                                    <div className="flex items-center justify-between mb-4 pt-4 border-t border-cyan-500/20">
                                        <span className="text-2xl font-bold tech-gradient-text">${product.price}</span>
                                        <div className="flex items-center gap-1 px-3 py-1.5 rounded-full tech-card border border-yellow-500/30">
                                            <span className="text-yellow-400 text-sm drop-shadow-[0_0_5px_rgba(250,204,21,0.5)]">★</span>
                                            <span className="text-sm font-bold text-yellow-400">{product.rating}</span>
                                            <span className="text-xs text-foreground/50 ml-1">({product.reviews})</span>
                                        </div>
                                    </div>

                                    <motion.button
                                        onClick={() => openBookingModal(product)}
                                        className="w-full py-3 bg-gradient-to-r from-cyan-500 to-purple-600 text-white rounded-xl font-semibold hover:shadow-lg hover:shadow-cyan-500/25 transition-all flex items-center justify-center gap-2 neon-pulse"
                                        whileHover={{ scale: 1.02 }}
                                        whileTap={{ scale: 0.98 }}
                                    >
                                        <Send className="w-4 h-4" />
                                        Order Now
                                    </motion.button>
                                </div>
                            </HolographicCard>
                        </ScrollReveal>
                    ))}
                </div>

                {filteredProducts.length === 0 && (
                    <div className="text-center py-20 tech-card rounded-3xl cyber-glow">
                        <p className="text-2xl text-muted-foreground mb-4">No services found</p>
                        <button
                            onClick={() => { setSelectedCategory('All'); setSearchQuery(''); }}
                            className="text-cyan-400 hover:text-cyan-300 hover:underline transition-colors"
                        >
                            Clear filters
                        </button>
                    </div>
                )}

                {/* Product Detail Modal */}
                <AnimatePresence>
                    {selectedProduct && !showBookingModal && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4"
                            onClick={() => setSelectedProduct(null)}
                        >
                            <motion.div
                                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                                animate={{ scale: 1, opacity: 1, y: 0 }}
                                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                                className="glass-card rounded-3xl max-w-4xl w-full overflow-hidden border border-white/10 shadow-2xl"
                                onClick={(e) => e.stopPropagation()}
                            >
                                <div className="relative">
                                    <button
                                        onClick={() => setSelectedProduct(null)}
                                        className="absolute top-4 right-4 p-2 rounded-full glass hover:bg-white/10 z-10 transition-colors"
                                    >
                                        <X className="w-6 h-6" />
                                    </button>

                                    <div className="grid md:grid-cols-2">
                                        <div className="relative h-64 md:h-auto">
                                            <img
                                                src={selectedProduct.image}
                                                alt={selectedProduct.name}
                                                className="w-full h-full object-cover"
                                            />
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                                            <div className="absolute bottom-6 left-6">
                                                <span className="px-3 py-1 rounded-full bg-primary text-primary-foreground text-sm font-semibold shadow-lg">
                                                    {selectedProduct.category}
                                                </span>
                                            </div>
                                        </div>

                                        <div className="p-8 flex flex-col h-full">
                                            <h2 className="text-3xl font-bold mb-4">{selectedProduct.name}</h2>
                                            <p className="text-muted-foreground mb-6 text-lg leading-relaxed">{selectedProduct.description}</p>

                                            <div className="flex items-center gap-4 mb-8 p-4 rounded-xl bg-white/5 border border-white/5">
                                                <span className="text-4xl font-bold gradient-text">${selectedProduct.price}</span>
                                                <div className="h-8 w-[1px] bg-white/10" />
                                                <div className="flex items-center gap-2">
                                                    <span className="text-yellow-400 text-2xl drop-shadow-md">★</span>
                                                    <div>
                                                        <div className="text-sm font-bold">{selectedProduct.rating} Rating</div>
                                                        <div className="text-xs text-muted-foreground">{selectedProduct.reviews} Reviews</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="space-y-4 mb-8">
                                                <div className="flex items-center justify-between text-sm">
                                                    <span className="text-muted-foreground">Availability:</span>
                                                    <span className="font-semibold text-green-400 flex items-center gap-2">
                                                        <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse shadow-[0_0_10px_rgba(74,222,128,0.5)]" />
                                                        Available Now
                                                    </span>
                                                </div>
                                                <div className="flex flex-wrap gap-2">
                                                    {selectedProduct.tags.map((tag) => (
                                                        <span key={tag} className="px-3 py-1 glass rounded-full text-xs font-medium uppercase tracking-wide text-muted-foreground border border-white/5">
                                                            {tag}
                                                        </span>
                                                    ))}
                                                </div>
                                            </div>

                                            <div className="mt-auto pt-6 border-t border-white/10">
                                                <button
                                                    onClick={() => openBookingModal(selectedProduct)}
                                                    className="w-full py-4 bg-primary text-primary-foreground rounded-xl font-bold text-lg hover:shadow-lg hover:shadow-primary/25 hover:scale-[1.02] transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                                                >
                                                    <Send className="w-5 h-5" />
                                                    Book This Service
                                                </button>
                                                <p className="text-center text-xs text-muted-foreground mt-3">
                                                    Secure payment • 24/7 Support • Money-back guarantee
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </motion.div>
                        </motion.div>
                    )}
                </AnimatePresence>

                {/* Booking Modal */}
                <AnimatePresence>
                    {showBookingModal && selectedProduct && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto"
                            onClick={() => setShowBookingModal(false)}
                        >
                            <motion.div
                                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                                animate={{ scale: 1, opacity: 1, y: 0 }}
                                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                                className="glass-card rounded-3xl max-w-2xl w-full border border-white/10 shadow-2xl my-8"
                                onClick={(e) => e.stopPropagation()}
                            >
                                <div className="p-8">
                                    <div className="flex items-center justify-between mb-6">
                                        <div>
                                            <h2 className="text-3xl font-bold mb-2">Book Service</h2>
                                            <p className="text-muted-foreground">{selectedProduct.name}</p>
                                        </div>
                                        <button
                                            onClick={() => setShowBookingModal(false)}
                                            className="p-2 rounded-full glass hover:bg-white/10 transition-colors"
                                        >
                                            <X className="w-6 h-6" />
                                        </button>
                                    </div>

                                    <form onSubmit={handleBookingSubmit} className="space-y-6">
                                        <div className="grid md:grid-cols-2 gap-4">
                                            <div>
                                                <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                                                    <User className="w-4 h-4" />
                                                    Full Name *
                                                </label>
                                                <input
                                                    type="text"
                                                    required
                                                    value={bookingForm.name}
                                                    onChange={(e) => setBookingForm({ ...bookingForm, name: e.target.value })}
                                                    className="w-full px-4 py-3 rounded-xl glass focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                                                    placeholder="John Doe"
                                                />
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                                                    <Mail className="w-4 h-4" />
                                                    Email *
                                                </label>
                                                <input
                                                    type="email"
                                                    required
                                                    value={bookingForm.email}
                                                    onChange={(e) => setBookingForm({ ...bookingForm, email: e.target.value })}
                                                    className="w-full px-4 py-3 rounded-xl glass focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                                                    placeholder="john@example.com"
                                                />
                                            </div>
                                        </div>

                                        <div className="grid md:grid-cols-2 gap-4">
                                            <div>
                                                <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                                                    <Phone className="w-4 h-4" />
                                                    Phone Number *
                                                </label>
                                                <input
                                                    type="tel"
                                                    required
                                                    value={bookingForm.phone}
                                                    onChange={(e) => setBookingForm({ ...bookingForm, phone: e.target.value })}
                                                    className="w-full px-4 py-3 rounded-xl glass focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                                                    placeholder="+1 234 567 8900"
                                                />
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium mb-2">
                                                    Company (Optional)
                                                </label>
                                                <input
                                                    type="text"
                                                    value={bookingForm.company}
                                                    onChange={(e) => setBookingForm({ ...bookingForm, company: e.target.value })}
                                                    className="w-full px-4 py-3 rounded-xl glass focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                                                    placeholder="Your Company"
                                                />
                                            </div>
                                        </div>

                                        <div>
                                            <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                                                <FileText className="w-4 h-4" />
                                                Project Details
                                            </label>
                                            <textarea
                                                value={bookingForm.projectDetails}
                                                onChange={(e) => setBookingForm({ ...bookingForm, projectDetails: e.target.value })}
                                                rows={4}
                                                className="w-full px-4 py-3 rounded-xl glass focus:outline-none focus:ring-2 focus:ring-primary transition-all resize-none"
                                                placeholder="Tell us about your project requirements..."
                                            />
                                        </div>

                                        <div className="grid md:grid-cols-2 gap-4">
                                            <div>
                                                <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                                                    <DollarSign className="w-4 h-4" />
                                                    Budget Range
                                                </label>
                                                <select
                                                    value={bookingForm.budget}
                                                    onChange={(e) => setBookingForm({ ...bookingForm, budget: e.target.value })}
                                                    className="w-full px-4 py-3 rounded-xl glass focus:outline-none focus:ring-2 focus:ring-primary transition-all bg-background/50 text-foreground"
                                                    style={{ colorScheme: 'dark' }}
                                                >
                                                    <option value="" className="bg-background text-foreground">Select budget</option>
                                                    <option value="<5000" className="bg-background text-foreground">Less than $5,000</option>
                                                    <option value="5000-10000" className="bg-background text-foreground">$5,000 - $10,000</option>
                                                    <option value="10000-25000" className="bg-background text-foreground">$10,000 - $25,000</option>
                                                    <option value="25000+" className="bg-background text-foreground">$25,000+</option>
                                                </select>
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                                                    <Calendar className="w-4 h-4" />
                                                    Timeline
                                                </label>
                                                <select
                                                    value={bookingForm.timeline}
                                                    onChange={(e) => setBookingForm({ ...bookingForm, timeline: e.target.value })}
                                                    className="w-full px-4 py-3 rounded-xl glass focus:outline-none focus:ring-2 focus:ring-primary transition-all bg-background/50 text-foreground"
                                                    style={{ colorScheme: 'dark' }}
                                                >
                                                    <option value="" className="bg-background text-foreground">Select timeline</option>
                                                    <option value="urgent" className="bg-background text-foreground">Urgent (1-2 weeks)</option>
                                                    <option value="short" className="bg-background text-foreground">Short (1 month)</option>
                                                    <option value="medium" className="bg-background text-foreground">Medium (2-3 months)</option>
                                                    <option value="long" className="bg-background text-foreground">Long (3+ months)</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div className="pt-6 border-t border-white/10 space-y-4">
                                            <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                                                <span className="text-lg font-medium">Total Estimate:</span>
                                                <span className="text-3xl font-bold gradient-text">${selectedProduct.price}</span>
                                            </div>

                                            <button
                                                type="submit"
                                                className="w-full py-4 bg-primary text-primary-foreground rounded-xl font-bold text-lg hover:shadow-lg hover:shadow-primary/25 hover:scale-[1.02] transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                                            >
                                                <Send className="w-5 h-5" />
                                                Submit Booking Request
                                            </button>

                                            <p className="text-center text-xs text-muted-foreground">
                                                By submitting, you agree to our terms and conditions. We'll contact you within 24 hours.
                                            </p>
                                        </div>
                                    </form>
                                </div>
                            </motion.div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
}

