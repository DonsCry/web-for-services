'use client';

import { motion } from 'framer-motion';
import { ArrowRight, Zap, Shield, Rocket, Users, TrendingUp, Star, Sparkles, Code, Database, Cloud } from 'lucide-react';
import ScrollReveal from '@/components/animations/scroll-reveal';
import Card3D from '@/components/animations/card-3d';
import MagneticButton from '@/components/animations/magnetic-button';
import MatrixRain from '@/components/animations/matrix-rain';
import HolographicCard from '@/components/animations/holographic-card';
import GlitchText from '@/components/animations/glitch-text';
import CyberGrid from '@/components/animations/cyber-grid';
import TypingAnimation from '@/components/animations/typing-animation';
import CounterAnimation from '@/components/animations/counter-animation';
import { useState, useEffect } from 'react';
import Link from 'next/link';

const features = [
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Optimized performance for blazing fast load times and smooth interactions.',
  },
  {
    icon: Shield,
    title: 'Secure & Safe',
    description: 'Enterprise-grade security to protect your data and privacy.',
  },
  {
    icon: Rocket,
    title: 'Modern Stack',
    description: 'Built with the latest technologies for scalability and reliability.',
  },
  {
    icon: Users,
    title: 'Team Collaboration',
    description: 'Work together seamlessly with powerful collaboration tools.',
  },
];

const statistics = [
  { label: 'Active Users', value: 50000, suffix: '+', prefix: '' },
  { label: 'Projects Completed', value: 1200, suffix: '+', prefix: '' },
  { label: 'Customer Satisfaction', value: 99, suffix: '%', prefix: '' },
  { label: 'Years Experience', value: 10, suffix: '+', prefix: '' },
];

const testimonials = [
  {
    name: 'Sarah Johnson',
    role: 'CEO, TechCorp',
    content: 'This platform transformed our workflow completely. Best decision we made!',
    rating: 5,
  },
  {
    name: 'Michael Chen',
    role: 'Designer, Creative Studio',
    content: 'The animations and user experience are absolutely stunning. Highly recommend!',
    rating: 5,
  },
  {
    name: 'Emma Williams',
    role: 'Developer, StartupHub',
    content: 'Clean code, great documentation, and amazing support. Perfect for our needs.',
    rating: 5,
  },
];

function CounterAnimationComponent({ target, suffix = '', prefix = '' }: { target: number; suffix?: string; prefix?: string }) {
  return (
    <CounterAnimation
      target={target}
      suffix={suffix}
      prefix={prefix}
      className="text-5xl font-bold tech-gradient-text"
    />
  );
}

export default function HomePage() {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative overflow-hidden">
      {/* Matrix Rain Background */}
      <MatrixRain className="opacity-20" speed={60} />

      {/* Cyber Grid Background */}
      <CyberGrid className="opacity-10" />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4">
        {/* Tech Background Effects */}
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-[120px] animate-pulse-glow" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-[120px] animate-pulse-glow" style={{ animationDelay: '1s' }} />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-pink-500/10 rounded-full blur-[100px]" />
        </div>

        <div className="max-w-7xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Tech Badge */}
            <motion.div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-vibrant border border-cyan-500/30 mb-6"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring' }}
            >
              <Code className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span className="text-sm font-semibold tech-gradient-text">Advanced Technology Solutions</span>
              <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
            </motion.div>

            {/* Main Title with Glitch Effect */}
            <GlitchText intensity="medium" className="mb-6">
              <h1 className="text-6xl md:text-8xl font-bold tech-gradient-text">
                Skyline Corps
              </h1>
            </GlitchText>

            {/* Typing Animation Subtitle */}
            <div className="text-2xl md:text-3xl mb-8 h-12 flex items-center justify-center">
              <TypingAnimation
                texts={[
                  'Building the Future of Technology',
                  'Innovative IT Solutions',
                  'Cutting-Edge Development',
                  'Digital Transformation Experts'
                ]}
                className="font-bold text-cyan-400"
                cursorColor="#06B6D4"
              />
            </div>

            <p className="text-lg md:text-xl text-foreground/80 mb-8 max-w-3xl mx-auto leading-relaxed">
              Transform your digital vision into reality with <span className="text-cyan-400 font-bold">innovative IT solutions</span>, <span className="text-purple-400 font-bold">cutting-edge technology</span>, and exceptional service.
            </p>
          </motion.div>

          {/* CTA Buttons with Tech Effects */}
          <motion.div
            className="flex flex-wrap gap-6 justify-center items-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
          >
            <Link href="/products">
              <MagneticButton className="group px-8 py-4 bg-gradient-to-r from-cyan-500 to-purple-600 text-white rounded-full font-bold text-lg hover:shadow-2xl hover:shadow-cyan-500/50 transition-all duration-300 flex items-center gap-3 neon-pulse">
                <Rocket className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                Get Started
                <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
              </MagneticButton>
            </Link>
            <Link href="/contact">
              <MagneticButton className="px-8 py-4 tech-card rounded-full font-bold text-lg hover:scale-105 cyber-glow transition-all duration-300 flex items-center gap-2">
                <Database className="w-5 h-5" />
                Contact Us
              </MagneticButton>
            </Link>
          </motion.div>

          {/* Trust Badge with Tech Styling */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 1 }}
            className="mt-20"
          >
            <motion.div
              className="inline-flex items-center gap-3 px-6 py-3 rounded-full tech-card cyber-glow"
              animate={{ scale: [1, 1.02, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Cloud className="w-5 h-5 text-cyan-400 animate-pulse" />
              <p className="text-sm font-bold tech-gradient-text">
                ✨ Trusted by 50,000+ users worldwide ✨
              </p>
              <Star className="w-5 h-5 text-purple-400 animate-pulse" />
            </motion.div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <div className="w-6 h-10 border-2 border-foreground/30 rounded-full p-1">
            <div className="w-1.5 h-3 bg-primary rounded-full mx-auto animate-float" />
          </div>
        </motion.div>
      </section>

      {/* Features Section with Holographic Cards */}
      <section className="py-32 px-4 relative">
        {/* Circuit Pattern Background */}
        <div className="absolute inset-0 circuit-pattern opacity-30" />

        <div className="max-w-7xl mx-auto relative z-10">
          <ScrollReveal>
            <div className="text-center mb-16">
              <motion.div
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full tech-card mb-6"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring' }}
              >
                <Zap className="w-4 h-4 text-cyan-400 animate-pulse" />
                <span className="text-sm font-semibold tech-gradient-text">Core Features</span>
              </motion.div>
              <h2 className="text-4xl md:text-6xl font-bold mb-6">
                <GlitchText intensity="low">
                  <span className="tech-gradient-text">Powerful Features</span>
                </GlitchText>
              </h2>
              <p className="text-center text-foreground/70 max-w-2xl mx-auto text-lg">
                Everything you need to build exceptional digital experiences with <span className="text-cyan-400 font-semibold">cutting-edge technology</span>
              </p>
            </div>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <ScrollReveal key={index} delay={index * 0.1}>
                <HolographicCard className="h-full">
                  <div className="p-8">
                    <motion.div
                      className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-purple-500/20 flex items-center justify-center mb-6 relative"
                      whileHover={{ scale: 1.2, rotate: 360 }}
                      transition={{ duration: 0.5 }}
                    >
                      <div className="absolute inset-0 rounded-2xl bg-cyan-400/20 blur-xl" />
                      <feature.icon className="w-8 h-8 text-cyan-400 relative z-10" />
                    </motion.div>
                    <h3 className="text-xl font-bold mb-3 tech-gradient-text">{feature.title}</h3>
                    <p className="text-foreground/70">{feature.description}</p>
                  </div>
                </HolographicCard>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Start Your Journey Section */}
      <section className="py-32 px-4 relative overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-purple-500/5 to-transparent animate-pulse-glow" />
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />

        <div className="max-w-7xl mx-auto relative">
          <ScrollReveal>
            <div className="text-center mb-20">
              <div className="inline-block px-6 py-2 rounded-full glass mb-6">
                <p className="text-sm font-semibold text-primary">🚀 Your Success Path</p>
              </div>
              <h2 className="text-5xl md:text-7xl font-bold mb-6 tech-gradient-text">
                Start Your Journey
              </h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Embark on a transformative adventure with us. From idea to execution, we'll guide you every step of the way.
              </p>
            </div>
          </ScrollReveal>

          {/* Journey Roadmap */}
          <div className="relative mb-32">
            {/* Timeline Line */}
            <div className="absolute left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-foreground/20 via-foreground/40 to-foreground/20 hidden lg:block" />

            {[
              {
                step: '01',
                title: 'Discovery',
                subtitle: 'Share Your Vision',
                description: 'Tell us about your goals, challenges, and dreams. We listen, understand, and craft a personalized strategy.',
                icon: '🎯',
                color: 'from-blue-500 to-cyan-500',
                achievements: ['Free Consultation', 'Strategy Blueprint', 'Timeline Planning']
              },
              {
                step: '02',
                title: 'Design',
                subtitle: 'Bring Ideas to Life',
                description: 'Our creative team transforms concepts into stunning visuals. Every pixel, every interaction is crafted with care.',
                icon: '🎨',
                color: 'from-purple-500 to-pink-500',
                achievements: ['Wireframes', 'UI/UX Design', 'Interactive Prototypes']
              },
              {
                step: '03',
                title: 'Development',
                subtitle: 'Build with Excellence',
                description: 'Expert developers turn designs into reality using cutting-edge technologies and best practices.',
                icon: '⚡',
                color: 'from-orange-500 to-red-500',
                achievements: ['Clean Code', 'Performance Optimization', 'Security Implementation']
              },
              {
                step: '04',
                title: 'Testing',
                subtitle: 'Ensure Perfection',
                description: 'Rigorous quality assurance ensures your product works flawlessly across all devices and scenarios.',
                icon: '✅',
                color: 'from-green-500 to-emerald-500',
                achievements: ['QA Testing', 'Bug Fixes', 'Performance Tuning']
              },
              {
                step: '05',
                title: 'Launch',
                subtitle: 'Go Live & Grow',
                description: 'Deploy with confidence and watch your vision come to life. We provide ongoing support for continuous success.',
                icon: '🚀',
                color: 'from-yellow-500 to-orange-500',
                achievements: ['Deployment', '24/7 Support', 'Growth Analytics']
              }
            ].map((stage, index) => (
              <ScrollReveal key={index} delay={index * 0.15}>
                <div className={`relative mb-16 lg:mb-24 ${index % 2 === 0 ? 'lg:pr-1/2' : 'lg:pl-1/2 lg:text-right'}`}>
                  <div className={`lg:w-1/2 ${index % 2 === 0 ? 'lg:pr-16' : 'lg:pl-16 lg:ml-auto'}`}>
                    <Card3D className="glass-card rounded-3xl p-8 relative overflow-hidden group">
                      {/* Gradient Background */}
                      <div className={`absolute inset-0 bg-gradient-to-br ${stage.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`} />

                      <div className="relative">
                        {/* Step Number */}
                        <div className="flex items-center gap-4 mb-6">
                          <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${stage.color} flex items-center justify-center text-4xl shadow-lg`}>
                            {stage.icon}
                          </div>
                          <div className={index % 2 === 0 ? '' : 'lg:text-right lg:ml-auto'}>
                            <div className="text-sm font-bold text-primary mb-1">STEP {stage.step}</div>
                            <h3 className="text-3xl font-bold">{stage.title}</h3>
                            <p className="text-sm text-muted-foreground">{stage.subtitle}</p>
                          </div>
                        </div>

                        {/* Description */}
                        <p className="text-muted-foreground mb-6 leading-relaxed">
                          {stage.description}
                        </p>

                        {/* Achievements */}
                        <div className="flex flex-wrap gap-2">
                          {stage.achievements.map((achievement, i) => (
                            <div key={i} className="px-3 py-1.5 rounded-full glass text-xs font-medium flex items-center gap-1.5">
                              <div className={`w-1.5 h-1.5 rounded-full bg-gradient-to-r ${stage.color}`} />
                              {achievement}
                            </div>
                          ))}
                        </div>

                        {/* Progress Bar */}
                        <div className="mt-6">
                          <div className="flex justify-between text-xs text-muted-foreground mb-2">
                            <span>Completion Rate</span>
                            <span>{95 + index}%</span>
                          </div>
                          <div className="h-2 bg-foreground/5 rounded-full overflow-hidden">
                            <motion.div
                              initial={{ width: 0 }}
                              whileInView={{ width: `${95 + index}%` }}
                              transition={{ duration: 1, delay: 0.5 }}
                              className={`h-full bg-gradient-to-r ${stage.color} rounded-full`}
                            />
                          </div>
                        </div>
                      </div>
                    </Card3D>
                  </div>

                  {/* Timeline Dot */}
                  <div className="hidden lg:block absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
                    <div className={`w-6 h-6 rounded-full bg-gradient-to-br ${stage.color} border-4 border-background shadow-lg`} />
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>

          {/* Success Metrics */}
          <ScrollReveal delay={0.3}>
            <div className="glass-card rounded-3xl p-12 relative overflow-hidden mb-20">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10 animate-pulse-glow" />
              <div className="relative">
                <h3 className="text-3xl font-bold text-center mb-12 tech-gradient-text">Your Success Milestones</h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                  {[
                    { icon: '🎯', label: 'Projects Launched', value: '1,200+', color: 'from-blue-500 to-cyan-500' },
                    { icon: '⭐', label: 'Avg. Rating', value: '4.9/5', color: 'from-yellow-500 to-orange-500' },
                    { icon: '🚀', label: 'Success Rate', value: '98%', color: 'from-green-500 to-emerald-500' },
                    { icon: '💎', label: 'Happy Clients', value: '500+', color: 'from-purple-500 to-pink-500' }
                  ].map((metric, index) => (
                    <div key={index} className="text-center">
                      <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${metric.color} flex items-center justify-center text-3xl mx-auto mb-4 shadow-lg`}>
                        {metric.icon}
                      </div>
                      <div className="text-4xl font-bold tech-gradient-text mb-2">{metric.value}</div>
                      <p className="text-sm text-muted-foreground">{metric.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </ScrollReveal>

          {/* Inspirational Quote */}
          <ScrollReveal delay={0.4}>
            <div className="text-center max-w-4xl mx-auto">
              <div className="glass-card rounded-3xl p-12 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-foreground/5 to-transparent" />
                <div className="relative">
                  <svg className="w-16 h-16 text-primary/30 mx-auto mb-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M14.017 21L14.017 18C14.017 16.0547 15.3738 14.7915 16.6266 13.605C18.0083 12.2969 19.5029 10.8819 19.5029 8.00004C19.5029 5.23861 17.2614 3.00004 14.5 3.00004C11.7386 3.00004 9.50004 5.23861 9.50004 8.00004C9.50004 8.1381 9.50569 8.27517 9.51684 8.41098L8.50293 8.41098C8.50293 8.41098 8.51348 8.27429 8.51348 8.00004C8.51348 4.68633 11.1863 2.00004 14.5 2.00004C17.8137 2.00004 20.5029 4.68633 20.5029 8.00004C20.5029 11.4326 18.6972 13.1425 17.3133 14.453C16.1466 15.5579 15.017 16.6279 15.017 18L15.017 21L14.017 21ZM6.51684 8.41098C6.52799 8.27517 6.53364 8.1381 6.53364 8.00004C6.53364 5.23861 4.29215 3.00004 1.53076 3.00004C1.23787 3.00004 0.951523 3.02557 0.673645 3.07465L0.673645 2.06073C0.950788 2.02026 1.23637 2.00004 1.53076 2.00004C4.84446 2.00004 7.53364 4.68633 7.53364 8.00004C7.53364 8.27429 7.52309 8.41098 7.52309 8.41098L6.51684 8.41098Z" />
                  </svg>
                  <blockquote className="text-3xl md:text-4xl font-bold mb-6 leading-relaxed">
                    "Every great journey begins with a single step. Let's take that step together."
                  </blockquote>
                  <p className="text-muted-foreground">
                    Join thousands of visionaries who transformed their ideas into reality with our guidance.
                  </p>
                  <div className="mt-8">
                    <Link href="/products">
                      <MagneticButton className="px-10 py-5 gradient-bg text-white rounded-full font-bold text-lg hover:shadow-2xl transition-all inline-flex items-center gap-3">
                        Begin Your Journey Now <ArrowRight className="w-6 h-6" />
                      </MagneticButton>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 relative">
        <div className="absolute inset-0 bg-primary/5 -skew-y-3 transform origin-left" />
        <div className="max-w-7xl mx-auto px-4 relative">
          <ScrollReveal>
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-bold mb-6 tech-gradient-text">Our Premium Services</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Comprehensive digital solutions tailored to elevate your business.
              </p>
            </div>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'UI/UX Design',
                desc: 'Stunning interfaces and intuitive user experiences designed to captivate and convert.',
                icon: '🎨',
                color: 'from-pink-500 to-rose-500'
              },
              {
                title: 'Mobile Development',
                desc: 'High-performance Flutter apps for iOS and Android with native-like feel.',
                icon: '📱',
                color: 'from-blue-500 to-cyan-500'
              },
              {
                title: 'Full Stack Web',
                desc: 'Scalable web applications with robust backends and dynamic frontends.',
                icon: '💻',
                color: 'from-purple-500 to-indigo-500'
              }
            ].map((service, index) => (
              <ScrollReveal key={index} delay={index * 0.1}>
                <HolographicCard className="h-full p-8 group">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${service.color} flex items-center justify-center text-3xl mb-6 shadow-lg relative`}>
                    <div className="absolute inset-0 rounded-2xl blur-xl opacity-50" style={{ background: `linear-gradient(to bottom right, ${service.color})` }} />
                    <span className="relative z-10">{service.icon}</span>
                  </div>
                  <h3 className="text-2xl font-bold mb-4 tech-gradient-text">{service.title}</h3>
                  <p className="text-foreground/70 mb-6">{service.desc}</p>
                  <MagneticButton className="w-full py-3 bg-gradient-to-r from-cyan-500 to-purple-600 text-white rounded-lg font-semibold hover:shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all">
                    Learn More
                  </MagneticButton>
                </HolographicCard>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-32 px-4 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {statistics.map((stat, index) => (
              <ScrollReveal key={index} delay={index * 0.1}>
                <div className="text-center">
                  <CounterAnimation
                    target={stat.value}
                    suffix={stat.suffix}
                    prefix={stat.prefix}
                  />
                  <p className="text-muted-foreground mt-2 text-lg">{stat.label}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Carousel */}
      <section className="py-32 px-4">
        <div className="max-w-4xl mx-auto">
          <ScrollReveal>
            <h2 className="text-4xl md:text-6xl font-bold text-center mb-16 tech-gradient-text">
              What Our Clients Say
            </h2>
          </ScrollReveal>

          <div className="relative h-80 overflow-hidden">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 100 }}
                animate={{
                  opacity: currentTestimonial === index ? 1 : 0,
                  x: currentTestimonial === index ? 0 : 100,
                }}
                transition={{ duration: 0.5 }}
                className="absolute inset-0 flex flex-col items-center justify-center text-center"
              >
                <div className="flex gap-1 mb-6">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400 drop-shadow-md" />
                  ))}
                </div>
                <p className="text-2xl mb-8 max-w-2xl">&ldquo;{testimonial.content}&rdquo;</p>
                <p className="font-semibold">{testimonial.name}</p>
                <p className="text-sm text-muted-foreground">{testimonial.role}</p>
              </motion.div>
            ))}
          </div>

          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentTestimonial(index)}
                className={`w-2 h-2 rounded-full transition-all ${currentTestimonial === index ? 'bg-primary w-8' : 'bg-foreground/20'
                  }`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 px-4">
        <ScrollReveal>
          <div className="max-w-4xl mx-auto text-center glass-card rounded-3xl p-16 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 animate-pulse-glow" />
            <div className="relative z-10">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 tech-gradient-text">
                Ready to Get Started?
              </h2>
              <p className="text-xl text-muted-foreground mb-8">
                Join thousands of satisfied customers and transform your digital presence today
              </p>
              <Link href="/products">
                <MagneticButton className="px-8 py-4 bg-white dark:bg-black text-black dark:text-white rounded-full font-semibold hover:shadow-2xl transition-shadow inline-flex items-center gap-2">
                  Start Your Journey <TrendingUp className="w-5 h-5" />
                </MagneticButton>
              </Link>
            </div>
          </div>
        </ScrollReveal>
      </section>
    </div>
  );
}
