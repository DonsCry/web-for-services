'use client';

import ScrollReveal from '@/components/animations/scroll-reveal';
import HolographicCard from '@/components/animations/holographic-card';
import GlitchText from '@/components/animations/glitch-text';
import MatrixRain from '@/components/animations/matrix-rain';
import CyberGrid from '@/components/animations/cyber-grid';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Users, ShoppingCart, DollarSign, Activity, MessageSquare, Star, Clock, Zap, Target, Award, Download, RefreshCw, ThumbsUp, Database, Sparkles } from 'lucide-react';
import { useState } from 'react';
import { motion } from 'framer-motion';

const data = [
    { name: 'Jan', sales: 4000 },
    { name: 'Feb', sales: 3000 },
    { name: 'Mar', sales: 2000 },
    { name: 'Apr', sales: 2780 },
    { name: 'May', sales: 1890 },
    { name: 'Jun', sales: 2390 },
];

const pieData = [
    { name: 'Mobile', value: 400, color: '#06B6D4' },
    { name: 'Web', value: 300, color: '#A855F7' },
    { name: 'Design', value: 200, color: '#EC4899' },
    { name: 'Other', value: 100, color: '#10B981' },
];

const stats = [
    { label: 'Total Revenue', value: '$48,574', icon: DollarSign, change: '+12%', color: 'from-green-500 to-emerald-600' },
    { label: 'Active Users', value: '12,483', icon: Users, change: '+8%', color: 'from-cyan-500 to-blue-600' },
    { label: 'Total Orders', value: '2,845', icon: ShoppingCart, change: '+23%', color: 'from-purple-500 to-pink-600' },
    { label: 'Growth Rate', value: '24.5%', icon: TrendingUp, change: '+5%', color: 'from-orange-500 to-red-600' },
];

const recentActivities = [
    {
        user: 'Sarah Johnson',
        avatar: 'https://i.pravatar.cc/150?img=1',
        action: 'purchased',
        item: 'Flutter Mobile App Development',
        comment: 'Amazing service! The team delivered beyond expectations. Highly recommended! 🚀',
        time: '2 minutes ago',
        type: 'purchase',
        rating: 5
    },
    {
        user: 'Michael Chen',
        avatar: 'https://i.pravatar.cc/150?img=13',
        action: 'reviewed',
        item: 'UI/UX Design Package',
        comment: 'The design quality is outstanding. Very professional and creative work!',
        time: '15 minutes ago',
        type: 'review',
        rating: 5
    },
    {
        user: 'Emma Williams',
        avatar: 'https://i.pravatar.cc/150?img=5',
        action: 'commented on',
        item: 'Full Stack Web Development',
        comment: 'Just started the project and the communication has been excellent so far.',
        time: '1 hour ago',
        type: 'comment',
        rating: 4
    },
    {
        user: 'David Martinez',
        avatar: 'https://i.pravatar.cc/150?img=12',
        action: 'purchased',
        item: 'Blockchain DApp Development',
        comment: 'Excited to work with this team! Their portfolio speaks for itself.',
        time: '2 hours ago',
        type: 'purchase',
        rating: 5
    },
];

const quickActions = [
    { label: 'New Order', icon: ShoppingCart, color: 'from-cyan-500 to-blue-600' },
    { label: 'Add Product', icon: Zap, color: 'from-purple-500 to-pink-600' },
    { label: 'View Reports', icon: Activity, color: 'from-orange-500 to-red-600' },
    { label: 'Messages', icon: MessageSquare, color: 'from-green-500 to-emerald-600' },
];

const performanceMetrics = [
    { label: 'Response Time', value: '2.4h', icon: Clock, change: '-15%' },
    { label: 'Satisfaction', value: '98%', icon: Star, change: '+3%' },
    { label: 'Completion', value: '94%', icon: Target, change: '+7%' },
    { label: 'Efficiency', value: '89%', icon: Award, change: '+12%' },
];

export default function DashboardPage() {
    const [activeFilter, setActiveFilter] = useState('all');

    const filteredActivities = activeFilter === 'all'
        ? recentActivities
        : recentActivities.filter(a => a.type === activeFilter);

    return (
        <div className="relative overflow-hidden min-h-screen pt-32 pb-20">
            {/* Background Effects */}
            <div className="fixed inset-0 z-0 pointer-events-none will-change-transform" style={{ transform: 'translate3d(0,0,0)' }}>
                <MatrixRain className="opacity-5" speed={60} />
                <CyberGrid className="opacity-5" />
            </div>

            <div className="max-w-7xl mx-auto px-4 relative z-10">
                {/* Header */}
                <ScrollReveal>
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-16">
                        <div>
                            <motion.div
                                initial={{ opacity: 0, scale: 0.5 }}
                                animate={{ opacity: 1, scale: 1 }}
                                className="inline-flex items-center gap-2 px-6 py-3 rounded-full tech-card cyber-glow mb-6"
                            >
                                <Database className="w-5 h-5 text-cyan-400 animate-pulse" />
                                <span className="text-sm font-bold tech-gradient-text">SYSTEM STATUS: ONLINE</span>
                                <Sparkles className="w-5 h-5 text-purple-400 animate-pulse" />
                            </motion.div>
                            <GlitchText intensity="low" className="mb-3">
                                <h1 className="text-5xl md:text-7xl font-bold tech-gradient-text">
                                    Dashboard
                                </h1>
                            </GlitchText>
                            <p className="text-lg text-foreground/70">Welcome back! Here's what's happening today.</p>
                        </div>
                        <div className="flex gap-4 mt-6 md:mt-0">
                            <motion.button
                                whileHover={{ scale: 1.05 }}
                                className="px-6 py-3 rounded-xl tech-card hover:border-cyan-500/50 transition-all flex items-center gap-2 hover:shadow-[0_0_20px_rgba(6,182,212,0.3)]"
                            >
                                <Download className="w-5 h-5 text-cyan-400" />
                                <span className="text-cyan-400 font-semibold">Export</span>
                            </motion.button>
                            <motion.button
                                whileHover={{ scale: 1.05 }}
                                className="px-6 py-3 rounded-xl tech-card hover:border-purple-500/50 transition-all flex items-center gap-2 hover:shadow-[0_0_20px_rgba(168,85,247,0.3)]"
                            >
                                <RefreshCw className="w-5 h-5 text-purple-400" />
                                <span className="text-purple-400 font-semibold">Refresh</span>
                            </motion.button>
                        </div>
                    </div>
                </ScrollReveal>

                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                    {stats.map((stat, index) => (
                        <ScrollReveal key={index} delay={index * 0.1}>
                            <HolographicCard className="p-8 group">
                                <div className="flex items-start justify-between mb-6">
                                    <motion.div
                                        className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${stat.color} flex items-center justify-center relative`}
                                        whileHover={{ scale: 1.1, rotate: 5 }}
                                    >
                                        <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${stat.color} blur-2xl opacity-50`} />
                                        <stat.icon className="w-8 h-8 text-white relative z-10" />
                                    </motion.div>
                                    <span className={`text-sm font-bold px-3 py-1 rounded-full ${stat.change.startsWith('+') ? 'bg-green-500/20 text-green-400 border border-green-500/40' : 'bg-red-500/20 text-red-400 border border-red-500/40'}`}>
                                        {stat.change}
                                    </span>
                                </div>
                                <p className="text-sm text-foreground/60 mb-2">{stat.label}</p>
                                <p className="text-4xl font-bold tech-gradient-text">{stat.value}</p>
                            </HolographicCard>
                        </ScrollReveal>
                    ))}
                </div>

                {/* Quick Actions */}
                <ScrollReveal delay={0.2}>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
                        {quickActions.map((action, index) => (
                            <HolographicCard key={index} className="p-8 text-center cursor-pointer group">
                                <motion.div
                                    className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${action.color} flex items-center justify-center mx-auto mb-4 relative`}
                                    whileHover={{ scale: 1.2, rotate: 360 }}
                                    transition={{ duration: 0.5 }}
                                >
                                    <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${action.color} blur-2xl opacity-50`} />
                                    <action.icon className="w-10 h-10 text-white relative z-10" />
                                </motion.div>
                                <p className="font-bold tech-gradient-text">{action.label}</p>
                            </HolographicCard>
                        ))}
                    </div>
                </ScrollReveal>

                {/* Charts */}
                <div className="grid lg:grid-cols-3 gap-8 mb-12">
                    <ScrollReveal delay={0.3} className="lg:col-span-2">
                        <HolographicCard className="p-8 h-full">
                            <div className="flex items-center justify-between mb-8">
                                <h2 className="text-3xl font-bold tech-gradient-text">Sales Overview</h2>
                                <div className="flex gap-3">
                                    <button className="px-4 py-2 rounded-xl text-sm bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 font-semibold">Monthly</button>
                                    <button className="px-4 py-2 rounded-xl text-sm tech-card hover:border-cyan-500/30 transition-all">Weekly</button>
                                </div>
                            </div>
                            <ResponsiveContainer width="100%" height={350}>
                                <BarChart data={data}>
                                    <CartesianGrid strokeDasharray="3 3" opacity={0.1} stroke="#06B6D4" />
                                    <XAxis dataKey="name" stroke="#06B6D4" />
                                    <YAxis stroke="#06B6D4" />
                                    <Tooltip
                                        contentStyle={{
                                            backgroundColor: 'rgba(0, 0, 0, 0.9)',
                                            border: '1px solid rgba(6, 182, 212, 0.3)',
                                            borderRadius: '12px',
                                            backdropFilter: 'blur(10px)',
                                        }}
                                    />
                                    <Bar dataKey="sales" fill="url(#colorGradient)" radius={[12, 12, 0, 0]} />
                                    <defs>
                                        <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="0%" stopColor="#06B6D4" />
                                            <stop offset="100%" stopColor="#A855F7" />
                                        </linearGradient>
                                    </defs>
                                </BarChart>
                            </ResponsiveContainer>
                        </HolographicCard>
                    </ScrollReveal>

                    <ScrollReveal delay={0.4}>
                        <HolographicCard className="p-8 h-full">
                            <h2 className="text-3xl font-bold mb-8 tech-gradient-text">Distribution</h2>
                            <ResponsiveContainer width="100%" height={300}>
                                <PieChart>
                                    <Pie
                                        data={pieData}
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={70}
                                        outerRadius={110}
                                        paddingAngle={5}
                                        dataKey="value"
                                    >
                                        {pieData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry.color} />
                                        ))}
                                    </Pie>
                                    <Tooltip
                                        contentStyle={{
                                            backgroundColor: 'rgba(0, 0, 0, 0.9)',
                                            border: '1px solid rgba(6, 182, 212, 0.3)',
                                            borderRadius: '12px',
                                        }}
                                    />
                                </PieChart>
                            </ResponsiveContainer>
                            <div className="grid grid-cols-2 gap-3 mt-6">
                                {pieData.map((item, index) => (
                                    <div key={index} className="flex items-center gap-2">
                                        <div className="w-4 h-4 rounded-full" style={{ backgroundColor: item.color, boxShadow: `0 0 10px ${item.color}` }} />
                                        <span className="text-sm text-foreground/70 font-semibold">{item.name}</span>
                                    </div>
                                ))}
                            </div>
                        </HolographicCard>
                    </ScrollReveal>
                </div>

                {/* Performance Metrics */}
                <ScrollReveal delay={0.5}>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
                        {performanceMetrics.map((metric, index) => (
                            <HolographicCard key={index} className="p-6">
                                <div className="flex items-center gap-4 mb-3">
                                    <motion.div
                                        className="w-14 h-14 rounded-xl bg-gradient-to-br from-cyan-500/20 to-purple-500/20 flex items-center justify-center border border-cyan-500/30"
                                        whileHover={{ scale: 1.1 }}
                                    >
                                        <metric.icon className="w-7 h-7 text-cyan-400" />
                                    </motion.div>
                                    <span className="text-xs font-bold text-green-400">{metric.change}</span>
                                </div>
                                <p className="text-xs text-foreground/60 mb-2">{metric.label}</p>
                                <p className="text-3xl font-bold tech-gradient-text">{metric.value}</p>
                            </HolographicCard>
                        ))}
                    </div>
                </ScrollReveal>

                {/* Recent Activity */}
                <ScrollReveal delay={0.6}>
                    <HolographicCard className="p-10">
                        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
                            <h2 className="text-3xl font-bold mb-6 md:mb-0 tech-gradient-text">Recent Activity</h2>
                            <div className="flex gap-3 flex-wrap">
                                {['all', 'purchase', 'review', 'comment'].map((filter) => (
                                    <button
                                        key={filter}
                                        onClick={() => setActiveFilter(filter)}
                                        className={`px-5 py-2 rounded-xl text-sm font-semibold transition-all ${activeFilter === filter
                                                ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white shadow-[0_0_20px_rgba(6,182,212,0.4)]'
                                                : 'tech-card hover:border-cyan-500/50'
                                            }`}
                                    >
                                        {filter.charAt(0).toUpperCase() + filter.slice(1)}
                                    </button>
                                ))}
                            </div>
                        </div>
                        <div className="space-y-6 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                            {filteredActivities.map((activity, index) => (
                                <motion.div
                                    key={index}
                                    className="tech-card rounded-2xl p-6 hover:border-cyan-500/50 transition-all hover:shadow-[0_0_20px_rgba(6,182,212,0.2)]"
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.05 }}
                                >
                                    <div className="flex gap-5">
                                        <img
                                            src={activity.avatar}
                                            alt={activity.user}
                                            className="w-16 h-16 rounded-full object-cover ring-2 ring-cyan-500/30"
                                        />
                                        <div className="flex-1">
                                            <div className="flex items-start justify-between mb-3">
                                                <div>
                                                    <p className="font-bold text-lg tech-gradient-text">{activity.user}</p>
                                                    <p className="text-sm text-foreground/70">
                                                        {activity.action} <span className="text-cyan-400 font-semibold">{activity.item}</span>
                                                    </p>
                                                </div>
                                                <span className="text-xs text-foreground/50 whitespace-nowrap ml-4">{activity.time}</span>
                                            </div>
                                            <div className="bg-black/40 rounded-xl p-4 mb-4 border border-cyan-500/20">
                                                <p className="text-sm italic text-foreground/80">&quot;{activity.comment}&quot;</p>
                                            </div>
                                            <div className="flex items-center gap-6">
                                                <div className="flex items-center gap-1">
                                                    {[...Array(5)].map((_, i) => (
                                                        <Star
                                                            key={i}
                                                            className={`w-5 h-5 ${i < activity.rating ? 'fill-yellow-400 text-yellow-400' : 'text-foreground/30'}`}
                                                        />
                                                    ))}
                                                </div>
                                                <button className="flex items-center gap-2 text-sm text-foreground/60 hover:text-cyan-400 transition-colors">
                                                    <ThumbsUp className="w-4 h-4" />
                                                    <span>Helpful</span>
                                                </button>
                                                <button className="flex items-center gap-2 text-sm text-foreground/60 hover:text-purple-400 transition-colors">
                                                    <MessageSquare className="w-4 h-4" />
                                                    <span>Reply</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    </HolographicCard>
                </ScrollReveal>
            </div>
        </div>
    );
}
