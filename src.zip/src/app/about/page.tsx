'use client';

import ScrollReveal from '@/components/animations/scroll-reveal';
import HolographicCard from '@/components/animations/holographic-card';
import GlitchText from '@/components/animations/glitch-text';
import CyberGrid from '@/components/animations/cyber-grid';
import MatrixRain from '@/components/animations/matrix-rain';
import { motion } from 'framer-motion';
import { Users, Target, Award, TrendingUp, Code, Globe, Zap, Shield, Database, Layout, Cpu, Layers, Sparkles, Rocket, Star } from 'lucide-react';

const timeline = [
    { year: '2014', title: 'System Initialization', description: 'Founded with a vision to revolutionize digital infrastructure.', icon: Rocket },
    { year: '2016', title: 'Core Deployment', description: 'Launched flagship product serving 10,000+ active nodes.', icon: Database },
    { year: '2019', title: 'Global Network', description: 'Expanded operations to 15 countries worldwide.', icon: Globe },
    { year: '2022', title: 'Market Dominance', description: 'Recognized as top innovator in digital experiences.', icon: Award },
    { year: '2024', title: 'Next-Gen Evolution', description: 'Pioneering AI integration and quantum-ready architecture.', icon: Sparkles },
];

const values = [
    {
        icon: Target,
        title: 'Mission Driven',
        description: 'Focused on solving complex problems with precision engineering and innovative solutions.',
        color: 'from-cyan-500 to-blue-600',
        iconColor: 'text-cyan-400'
    },
    {
        icon: Users,
        title: 'User Centric',
        description: 'Every protocol is designed with the end-user experience and satisfaction in mind.',
        color: 'from-purple-500 to-pink-600',
        iconColor: 'text-purple-400'
    },
    {
        icon: Award,
        title: 'Excellence',
        description: 'Committed to delivering zero-defect quality in every deployment and project.',
        color: 'from-pink-500 to-rose-600',
        iconColor: 'text-pink-400'
    },
    {
        icon: TrendingUp,
        title: 'Innovation',
        description: 'Constantly pushing boundaries to stay ahead of the technological curve.',
        color: 'from-green-500 to-emerald-600',
        iconColor: 'text-green-400'
    },
];

const stats = [
    { value: '10+', label: 'Years Experience', icon: Star },
    { value: '500+', label: 'Projects Completed', icon: Rocket },
    { value: '50K+', label: 'Active Users', icon: Users },
    { value: '99%', label: 'Satisfaction Rate', icon: Award },
];

export default function AboutPage() {
    return (
        <div className="relative min-h-screen pt-32 pb-20">
            {/* Background Effects */}
            <div className="fixed inset-0 z-0 pointer-events-none will-change-transform" style={{ transform: 'translate3d(0,0,0)' }}>
                <MatrixRain className="opacity-5" />
                <CyberGrid className="opacity-5" />
            </div>

            <div className="relative z-10 max-w-7xl mx-auto px-4">
                {/* Hero Section */}
                <ScrollReveal>
                    <div className="text-center mb-32">
                        <motion.div
                            initial={{ opacity: 0, y: -20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="inline-flex items-center gap-2 px-6 py-3 rounded-full tech-card cyber-glow mb-8"
                        >
                            <Cpu className="w-5 h-5 text-cyan-400 animate-pulse" />
                            <span className="text-sm font-bold tech-gradient-text">SYSTEM STATUS: ONLINE</span>
                            <Sparkles className="w-5 h-5 text-purple-400 animate-pulse" />
                        </motion.div>

                        <GlitchText intensity="medium" className="mb-8">
                            <h1 className="text-6xl md:text-8xl font-bold tech-gradient-text">
                                About Skyline Corps
                            </h1>
                        </GlitchText>

                        <p className="text-xl md:text-2xl text-foreground/70 max-w-4xl mx-auto leading-relaxed mb-12">
                            We're on a mission to <span className="text-cyan-400 font-bold">transform digital experiences</span> through
                            <span className="text-purple-400 font-bold"> innovative technology</span> and
                            <span className="text-pink-400 font-bold"> exceptional design</span>.
                        </p>

                        {/* Stats Row */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
                            {stats.map((stat, index) => (
                                <motion.div
                                    key={index}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.1 }}
                                    className="text-center"
                                >
                                    <div className="tech-card p-6 rounded-2xl hover:cyber-glow transition-all group">
                                        <stat.icon className="w-8 h-8 text-cyan-400 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                                        <div className="text-4xl font-bold tech-gradient-text mb-2">{stat.value}</div>
                                        <div className="text-sm text-foreground/60">{stat.label}</div>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    </div>
                </ScrollReveal>

                {/* Core Values */}
                <section className="mb-32">
                    <ScrollReveal>
                        <div className="text-center mb-16">
                            <h2 className="text-5xl md:text-6xl font-bold tech-gradient-text mb-4">Core Values</h2>
                            <div className="h-1 w-32 bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 mx-auto rounded-full" />
                        </div>
                    </ScrollReveal>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {values.map((value, index) => (
                            <ScrollReveal key={index} delay={index * 0.1}>
                                <HolographicCard className="p-10 h-full group cursor-pointer">
                                    <div className="flex items-start gap-6">
                                        <motion.div
                                            className={`relative w-20 h-20 rounded-2xl bg-gradient-to-br ${value.color} flex items-center justify-center flex-shrink-0`}
                                            whileHover={{ scale: 1.1, rotate: 5 }}
                                            transition={{ duration: 0.3 }}
                                        >
                                            <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${value.color} blur-2xl opacity-50`} />
                                            <value.icon className="w-10 h-10 text-white relative z-10" />
                                        </motion.div>
                                        <div className="flex-1">
                                            <h3 className="text-2xl font-bold mb-3 tech-gradient-text">{value.title}</h3>
                                            <p className="text-foreground/70 leading-relaxed">{value.description}</p>
                                        </div>
                                    </div>
                                </HolographicCard>
                            </ScrollReveal>
                        ))}
                    </div>
                </section>

                {/* Timeline */}
                <section className="mb-32">
                    <ScrollReveal>
                        <div className="text-center mb-20">
                            <h2 className="text-5xl md:text-6xl font-bold tech-gradient-text mb-4">Our Journey</h2>
                            <p className="text-xl text-foreground/60">A decade of innovation and growth</p>
                        </div>
                    </ScrollReveal>

                    <div className="relative max-w-5xl mx-auto">
                        {/* Vertical Line */}
                        <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-cyan-500/0 via-cyan-500/50 to-purple-500/0 hidden md:block" />

                        {timeline.map((event, index) => (
                            <ScrollReveal key={index} delay={index * 0.1}>
                                <motion.div
                                    className={`mb-16 flex items-center ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'} flex-col gap-8`}
                                    initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                                    whileInView={{ opacity: 1, x: 0 }}
                                    transition={{ duration: 0.5 }}
                                >
                                    <div className={`w-full md:w-5/12 ${index % 2 === 0 ? 'md:text-right' : ''}`}>
                                        <HolographicCard className="p-8 group">
                                            <div className={`flex items-center gap-4 mb-4 ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}>
                                                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                                                    <event.icon className="w-8 h-8 text-white" />
                                                </div>
                                                <div className="text-4xl font-bold text-cyan-400 font-mono">{event.year}</div>
                                            </div>
                                            <h3 className="text-2xl font-bold mb-3 text-white">{event.title}</h3>
                                            <p className="text-foreground/70">{event.description}</p>
                                        </HolographicCard>
                                    </div>

                                    {/* Center Dot */}
                                    <div className="hidden md:flex w-2/12 justify-center">
                                        <div className="w-6 h-6 rounded-full bg-gradient-to-br from-cyan-500 to-purple-600 border-4 border-background shadow-[0_0_20px_rgba(6,182,212,0.8)]" />
                                    </div>

                                    <div className="hidden md:block w-5/12" />
                                </motion.div>
                            </ScrollReveal>
                        ))}
                    </div>
                </section>

                {/* Leadership */}
                <section className="mb-32">
                    <ScrollReveal>
                        <div className="text-center mb-16">
                            <h2 className="text-5xl md:text-6xl font-bold tech-gradient-text mb-4">Leadership</h2>
                            <p className="text-xl text-foreground/60">The visionary behind our innovation</p>
                        </div>
                    </ScrollReveal>

                    <div className="max-w-2xl mx-auto">
                        <ScrollReveal>
                            <HolographicCard className="overflow-hidden group">
                                <div className="relative h-[500px] overflow-hidden">
                                    <img
                                        src="/ceo-founder.jpg"
                                        alt="Ahmad Revaldi Saputra"
                                        className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-700 grayscale hover:grayscale-0"
                                    />
                                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
                                    <div className="absolute bottom-0 left-0 right-0 p-10">
                                        <h3 className="text-4xl font-bold mb-2 text-white">Ahmad Revaldi Saputra</h3>
                                        <div className="flex items-center gap-3 text-cyan-400 text-lg font-mono mb-4">
                                            <span className="px-3 py-1 bg-cyan-500/20 border border-cyan-500/50 rounded-full">CEO</span>
                                            <span className="px-3 py-1 bg-purple-500/20 border border-purple-500/50 rounded-full">FOUNDER</span>
                                        </div>
                                        <div className="flex flex-wrap gap-2 mb-6">
                                            <span className="px-3 py-1 rounded-full bg-white/10 border border-white/20 text-sm">CTO</span>
                                            <span className="px-3 py-1 rounded-full bg-white/10 border border-white/20 text-sm">Head of Design</span>
                                            <span className="px-3 py-1 rounded-full bg-white/10 border border-white/20 text-sm">Lead Developer</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="p-10 bg-black/60 backdrop-blur-xl border-t border-cyan-500/20">
                                    <blockquote className="text-xl italic text-foreground/80 mb-6 leading-relaxed">
                                        "Innovation isn't just about building new things; it's about <span className="text-cyan-400 font-bold">redefining what's possible</span>.
                                        We don't just write code, we <span className="text-purple-400 font-bold">craft digital legacies</span>."
                                    </blockquote>
                                    <div className="flex justify-center gap-4">
                                        <motion.div whileHover={{ scale: 1.2 }} className="p-3 rounded-full tech-card cursor-pointer hover:text-cyan-400 transition-colors">
                                            <Globe className="w-6 h-6" />
                                        </motion.div>
                                        <motion.div whileHover={{ scale: 1.2 }} className="p-3 rounded-full tech-card cursor-pointer hover:text-purple-400 transition-colors">
                                            <Zap className="w-6 h-6" />
                                        </motion.div>
                                        <motion.div whileHover={{ scale: 1.2 }} className="p-3 rounded-full tech-card cursor-pointer hover:text-pink-400 transition-colors">
                                            <Code className="w-6 h-6" />
                                        </motion.div>
                                    </div>
                                </div>
                            </HolographicCard>
                        </ScrollReveal>
                    </div>
                </section>

                {/* CTA */}
                <section>
                    <ScrollReveal>
                        <HolographicCard className="p-16 text-center relative overflow-hidden">
                            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-pink-500/10" />
                            <div className="relative z-10">
                                <h2 className="text-5xl md:text-6xl font-bold mb-6 tech-gradient-text">Ready to Build the Future?</h2>
                                <p className="text-xl text-foreground/70 mb-10 max-w-3xl mx-auto leading-relaxed">
                                    Join our team of innovators and help shape the next generation of digital experiences.
                                    Let's create something extraordinary together.
                                </p>
                                <motion.button
                                    whileHover={{ scale: 1.05 }}
                                    whileTap={{ scale: 0.95 }}
                                    className="px-12 py-5 bg-gradient-to-r from-cyan-500 to-purple-600 text-white rounded-full font-bold text-lg hover:shadow-[0_0_40px_rgba(6,182,212,0.6)] transition-all inline-flex items-center gap-3"
                                >
                                    <Rocket className="w-6 h-6" />
                                    Join Our Team
                                    <Sparkles className="w-6 h-6" />
                                </motion.button>
                            </div>
                        </HolographicCard>
                    </ScrollReveal>
                </section>
            </div>
        </div>
    );
}
