'use client';

import { useState } from 'react';
import { Mail, Phone, MapPin, Send, Radio, Clock, MessageCircle, Sparkles } from 'lucide-react';
import ScrollReveal from '@/components/animations/scroll-reveal';
import HolographicCard from '@/components/animations/holographic-card';
import GlitchText from '@/components/animations/glitch-text';
import CyberGrid from '@/components/animations/cyber-grid';
import MatrixRain from '@/components/animations/matrix-rain';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import dynamic from 'next/dynamic';

const Map = dynamic(() => import('@/components/ui/map'), {
    ssr: false,
    loading: () => (
        <div className="w-full h-[500px] tech-card rounded-2xl animate-pulse flex items-center justify-center">
            <p className="text-cyan-400 font-mono">Loading Map...</p>
        </div>
    )
});

export default function ContactPage() {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: '',
    });
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);

        try {
            await new Promise(resolve => setTimeout(resolve, 1500));

            toast.success('Message sent successfully!', {
                style: {
                    background: '#0A0E27',
                    color: '#00FF41',
                    border: '1px solid #0EA5E9',
                },
            });
            setFormData({ name: '', email: '', subject: '', message: '' });
        } catch (error) {
            toast.error('Failed to send message. Please try again.');
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData(prev => ({
            ...prev,
            [e.target.name]: e.target.value
        }));
    };

    return (
        <div className="relative min-h-screen pt-32 pb-20">
            {/* Background Effects */}
            <div className="fixed inset-0 z-0 pointer-events-none will-change-transform" style={{ transform: 'translate3d(0,0,0)' }}>
                <MatrixRain className="opacity-5" />
                <CyberGrid className="opacity-5" />
            </div>

            <div className="relative z-10 max-w-7xl mx-auto px-4">
                {/* Hero */}
                <ScrollReveal>
                    <div className="text-center mb-24">
                        <motion.div
                            initial={{ opacity: 0, scale: 0.5 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="inline-flex items-center gap-2 px-6 py-3 rounded-full tech-card cyber-glow mb-8"
                        >
                            <Radio className="w-5 h-5 text-cyan-400 animate-pulse" />
                            <span className="text-sm font-bold tech-gradient-text">COMMUNICATION CHANNEL: ACTIVE</span>
                            <Sparkles className="w-5 h-5 text-purple-400 animate-pulse" />
                        </motion.div>

                        <GlitchText intensity="medium" className="mb-8">
                            <h1 className="text-6xl md:text-8xl font-bold tech-gradient-text">
                                Get in Touch
                            </h1>
                        </GlitchText>

                        <p className="text-xl md:text-2xl text-foreground/70 max-w-3xl mx-auto leading-relaxed">
                            Have a question or want to work together? <span className="text-cyan-400 font-bold">Initiate contact</span> and
                            we'll respond within <span className="text-purple-400 font-bold">24 hours</span>.
                        </p>
                    </div>
                </ScrollReveal>

                {/* Main Content */}
                <div className="grid lg:grid-cols-5 gap-12 mb-20">
                    {/* Contact Form - Takes 3 columns */}
                    <div className="lg:col-span-3">
                        <ScrollReveal delay={0.1}>
                            <HolographicCard className="p-10">
                                <div className="flex items-center gap-3 mb-8">
                                    <MessageCircle className="w-8 h-8 text-cyan-400" />
                                    <h2 className="text-4xl font-bold tech-gradient-text">Send Message</h2>
                                </div>

                                <form onSubmit={handleSubmit} className="space-y-6">
                                    <div className="grid md:grid-cols-2 gap-6">
                                        <div>
                                            <label htmlFor="name" className="block text-sm font-bold mb-3 text-cyan-400">
                                                Your Name *
                                            </label>
                                            <input
                                                type="text"
                                                id="name"
                                                name="name"
                                                value={formData.name}
                                                onChange={handleChange}
                                                required
                                                className="w-full px-5 py-4 rounded-xl tech-card bg-black/40 border border-cyan-500/30 focus:outline-none focus:border-cyan-500 focus:shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all text-white placeholder:text-foreground/40"
                                                placeholder="John Doe"
                                            />
                                        </div>

                                        <div>
                                            <label htmlFor="email" className="block text-sm font-bold mb-3 text-cyan-400">
                                                Email Address *
                                            </label>
                                            <input
                                                type="email"
                                                id="email"
                                                name="email"
                                                value={formData.email}
                                                onChange={handleChange}
                                                required
                                                className="w-full px-5 py-4 rounded-xl tech-card bg-black/40 border border-cyan-500/30 focus:outline-none focus:border-cyan-500 focus:shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all text-white placeholder:text-foreground/40"
                                                placeholder="john@example.com"
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <label htmlFor="subject" className="block text-sm font-bold mb-3 text-cyan-400">
                                            Subject *
                                        </label>
                                        <input
                                            type="text"
                                            id="subject"
                                            name="subject"
                                            value={formData.subject}
                                            onChange={handleChange}
                                            required
                                            className="w-full px-5 py-4 rounded-xl tech-card bg-black/40 border border-cyan-500/30 focus:outline-none focus:border-cyan-500 focus:shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all text-white placeholder:text-foreground/40"
                                            placeholder="What's this about?"
                                        />
                                    </div>

                                    <div>
                                        <label htmlFor="message" className="block text-sm font-bold mb-3 text-cyan-400">
                                            Message *
                                        </label>
                                        <textarea
                                            id="message"
                                            name="message"
                                            value={formData.message}
                                            onChange={handleChange}
                                            required
                                            rows={8}
                                            className="w-full px-5 py-4 rounded-xl tech-card bg-black/40 border border-cyan-500/30 focus:outline-none focus:border-cyan-500 focus:shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all text-white placeholder:text-foreground/40 resize-none"
                                            placeholder="Tell us more about your project..."
                                        />
                                    </div>

                                    <motion.button
                                        type="submit"
                                        disabled={isSubmitting}
                                        whileHover={{ scale: 1.02 }}
                                        whileTap={{ scale: 0.98 }}
                                        className="w-full py-5 bg-gradient-to-r from-cyan-500 to-purple-600 text-white rounded-full font-bold text-lg hover:shadow-[0_0_40px_rgba(6,182,212,0.6)] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3 relative overflow-hidden group"
                                    >
                                        <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-cyan-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                                        <span className="relative z-10 flex items-center gap-3">
                                            {isSubmitting ? (
                                                <>
                                                    <span className="inline-block animate-spin">⚡</span>
                                                    Transmitting...
                                                </>
                                            ) : (
                                                <>
                                                    Send Message <Send className="w-6 h-6" />
                                                </>
                                            )}
                                        </span>
                                    </motion.button>
                                </form>
                            </HolographicCard>
                        </ScrollReveal>
                    </div>

                    {/* Contact Info - Takes 2 columns */}
                    <div className="lg:col-span-2 space-y-6">
                        <ScrollReveal delay={0.2}>
                            <HolographicCard className="p-8 group cursor-pointer">
                                <div className="flex items-start gap-5">
                                    <div className="relative">
                                        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center flex-shrink-0">
                                            <Mail className="w-8 h-8 text-white" />
                                        </div>
                                        <div className="absolute inset-0 bg-cyan-500/30 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-xl mb-3 text-white">Email</h3>
                                        <p className="text-cyan-400 font-mono text-sm mb-1">hello@skylinecorps.com</p>
                                        <p className="text-purple-400 font-mono text-sm">support@skylinecorps.com</p>
                                    </div>
                                </div>
                            </HolographicCard>
                        </ScrollReveal>

                        <ScrollReveal delay={0.3}>
                            <HolographicCard className="p-8 group cursor-pointer">
                                <div className="flex items-start gap-5">
                                    <div className="relative">
                                        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center flex-shrink-0">
                                            <Phone className="w-8 h-8 text-white" />
                                        </div>
                                        <div className="absolute inset-0 bg-purple-500/30 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-xl mb-3 text-white">Phone</h3>
                                        <p className="text-cyan-400 font-mono text-sm mb-1">+1 (555) 123-4567</p>
                                        <p className="text-foreground/60 text-sm">Mon-Fri, 9am-6pm EST</p>
                                    </div>
                                </div>
                            </HolographicCard>
                        </ScrollReveal>

                        <ScrollReveal delay={0.4}>
                            <HolographicCard className="p-8 group cursor-pointer">
                                <div className="flex items-start gap-5">
                                    <div className="relative">
                                        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center flex-shrink-0">
                                            <MapPin className="w-8 h-8 text-white" />
                                        </div>
                                        <div className="absolute inset-0 bg-pink-500/30 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-xl mb-3 text-white">Office</h3>
                                        <p className="text-foreground/70 text-sm mb-1">123 Innovation Street</p>
                                        <p className="text-foreground/70 text-sm">San Francisco, CA 94105</p>
                                    </div>
                                </div>
                            </HolographicCard>
                        </ScrollReveal>

                        <ScrollReveal delay={0.5}>
                            <HolographicCard className="p-8">
                                <div className="flex items-center gap-3 mb-6">
                                    <Clock className="w-7 h-7 text-cyan-400" />
                                    <h3 className="text-2xl font-bold tech-gradient-text">Operating Hours</h3>
                                </div>
                                <div className="space-y-3 text-foreground/70 font-mono">
                                    <div className="flex justify-between items-center p-3 rounded-lg tech-card">
                                        <span>Monday - Friday:</span>
                                        <span className="text-cyan-400 font-bold">09:00 - 18:00</span>
                                    </div>
                                    <div className="flex justify-between items-center p-3 rounded-lg tech-card">
                                        <span>Saturday:</span>
                                        <span className="text-purple-400 font-bold">10:00 - 16:00</span>
                                    </div>
                                    <div className="flex justify-between items-center p-3 rounded-lg tech-card">
                                        <span>Sunday:</span>
                                        <span className="text-red-400 font-bold">OFFLINE</span>
                                    </div>
                                </div>
                            </HolographicCard>
                        </ScrollReveal>
                    </div>
                </div>

                {/* Map Section */}
                <ScrollReveal>
                    <HolographicCard className="overflow-hidden relative">
                        <div className="absolute top-4 left-4 w-3 h-3 border-t-2 border-l-2 border-cyan-500 z-10" />
                        <div className="absolute top-4 right-4 w-3 h-3 border-t-2 border-r-2 border-cyan-500 z-10" />
                        <div className="absolute bottom-4 left-4 w-3 h-3 border-b-2 border-l-2 border-cyan-500 z-10" />
                        <div className="absolute bottom-4 right-4 w-3 h-3 border-b-2 border-r-2 border-cyan-500 z-10" />

                        <div className="p-4">
                            <Map />
                        </div>
                    </HolographicCard>
                </ScrollReveal>
            </div>
        </div>
    );
}
