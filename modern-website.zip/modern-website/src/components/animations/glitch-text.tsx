'use client';

import { motion } from 'framer-motion';
import { ReactNode, useState } from 'react';

interface GlitchTextProps {
    children: ReactNode;
    className?: string;
    intensity?: 'low' | 'medium' | 'high';
}

export default function GlitchText({
    children,
    className = '',
    intensity = 'medium'
}: GlitchTextProps) {
    const [isGlitching, setIsGlitching] = useState(false);

    const glitchVariants = {
        low: { x: [-2, 2, -2, 0], duration: 0.2 },
        medium: { x: [-5, 5, -3, 3, 0], duration: 0.3 },
        high: { x: [-10, 10, -8, 8, -5, 5, 0], duration: 0.5 }
    };

    return (
        <div
            className={`relative inline-block ${className}`}
            onMouseEnter={() => setIsGlitching(true)}
            onMouseLeave={() => setIsGlitching(false)}
        >
            {/* Main text */}
            <motion.div
                animate={isGlitching ? {
                    x: glitchVariants[intensity].x,
                } : {}}
                transition={{
                    duration: glitchVariants[intensity].duration,
                    repeat: isGlitching ? Infinity : 0,
                }}
                className="relative z-10"
            >
                {children}
            </motion.div>

            {/* Glitch layers */}
            {isGlitching && (
                <>
                    <motion.div
                        className="absolute inset-0 text-cyan-400 opacity-70"
                        animate={{
                            x: [-3, 3, -2, 2, 0],
                            opacity: [0.7, 0.3, 0.7, 0.3, 0.7]
                        }}
                        transition={{
                            duration: 0.2,
                            repeat: Infinity,
                        }}
                        style={{ mixBlendMode: 'screen' }}
                    >
                        {children}
                    </motion.div>
                    <motion.div
                        className="absolute inset-0 text-pink-400 opacity-70"
                        animate={{
                            x: [3, -3, 2, -2, 0],
                            opacity: [0.7, 0.3, 0.7, 0.3, 0.7]
                        }}
                        transition={{
                            duration: 0.2,
                            repeat: Infinity,
                            delay: 0.1
                        }}
                        style={{ mixBlendMode: 'screen' }}
                    >
                        {children}
                    </motion.div>
                </>
            )}
        </div>
    );
}
