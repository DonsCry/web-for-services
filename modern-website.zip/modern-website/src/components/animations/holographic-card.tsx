'use client';

import { motion } from 'framer-motion';
import { ReactNode } from 'react';

interface HolographicCardProps {
    children: ReactNode;
    className?: string;
    glowColor?: string;
}

export default function HolographicCard({
    children,
    className = '',
    glowColor = 'cyan'
}: HolographicCardProps) {
    return (
        <motion.div
            className={`relative group ${className}`}
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.3 }}
        >
            {/* Holographic glow effect */}
            <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 rounded-2xl opacity-0 group-hover:opacity-75 blur-lg transition-opacity duration-500 animate-pulse-glow" />

            {/* Scan line effect */}
            <div className="absolute inset-0 overflow-hidden rounded-2xl pointer-events-none">
                <motion.div
                    className="absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent"
                    animate={{
                        y: [0, 400, 0],
                    }}
                    transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: "linear"
                    }}
                    style={{ opacity: 0.5 }}
                />
            </div>

            {/* Main card */}
            <div className="relative bg-gradient-to-br from-slate-900/90 via-slate-800/90 to-slate-900/90 backdrop-blur-xl rounded-2xl border border-cyan-500/20 overflow-hidden">
                {/* Holographic shimmer */}
                <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 via-transparent to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                {/* Grid pattern */}
                <div className="absolute inset-0 opacity-10">
                    <div className="absolute inset-0" style={{
                        backgroundImage: `
                            linear-gradient(to right, cyan 1px, transparent 1px),
                            linear-gradient(to bottom, cyan 1px, transparent 1px)
                        `,
                        backgroundSize: '20px 20px'
                    }} />
                </div>

                {/* Content */}
                <div className="relative z-10">
                    {children}
                </div>

                {/* Corner accents */}
                <div className="absolute top-0 left-0 w-20 h-20 border-t-2 border-l-2 border-cyan-400/50 rounded-tl-2xl" />
                <div className="absolute bottom-0 right-0 w-20 h-20 border-b-2 border-r-2 border-purple-400/50 rounded-br-2xl" />
            </div>
        </motion.div>
    );
}
