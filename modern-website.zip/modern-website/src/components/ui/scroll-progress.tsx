'use client';

import { motion } from 'framer-motion';

interface ScrollProgressProps {
    className?: string;
}

export default function ScrollProgress({ className = '' }: ScrollProgressProps) {
    return (
        <motion.div
            className={`fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-600 origin-left z-50 ${className}`}
            style={{
                scaleX: 0,
            }}
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: false }}
        />
    );
}
