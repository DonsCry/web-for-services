'use client';

import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { useEffect, useState } from 'react';
import L from 'leaflet';

// Fix for default marker icon
const icon = L.icon({
    iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
    iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
    shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41],
});

export default function Map() {
    const [isMounted, setIsMounted] = useState(false);

    useEffect(() => {
        setIsMounted(true);
    }, []);

    if (!isMounted) {
        return (
            <div className="w-full h-[400px] bg-muted/20 rounded-xl animate-pulse flex items-center justify-center">
                <p className="text-muted-foreground">Loading Map...</p>
            </div>
        );
    }

    // Coordinates for Jakarta (Example)
    const position: [number, number] = [-6.2088, 106.8456];

    return (
        <MapContainer
            center={position}
            zoom={13}
            scrollWheelZoom={false}
            className="w-full h-[400px] rounded-xl z-0"
        >
            <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <Marker position={position} icon={icon}>
                <Popup>
                    <div className="text-center">
                        <h3 className="font-bold text-primary">Modern Web Studio</h3>
                        <p className="text-sm">Jakarta, Indonesia</p>
                    </div>
                </Popup>
            </Marker>
        </MapContainer>
    );
}
