'use client';

import Link from 'next/link';
import { Github, Twitter, Linkedin, Mail, Heart, Sparkles } from 'lucide-react';
import ScrollReveal from '@/components/animations/scroll-reveal';
import { motion } from 'framer-motion';

export default function Footer() {
    const currentYear = new Date().getFullYear();

    const socialLinks = [
        {
            href: 'https://github.com/DonsCry',
            icon: Github,
            label: 'GitHub',
            color: 'hover:bg-purple-600',
            glow: 'hover:neon-glow-purple'
        },
        {
            href: 'https://linkedin.com/company/skylinecorps',
            icon: Linkedin,
            label: 'LinkedIn',
            color: 'hover:bg-cyan-500',
            glow: 'hover:neon-glow'
        },
        {
            href: 'mailto:info@skylinecorps.com',
            icon: Mail,
            label: 'Email',
            color: 'hover:bg-pink-500',
            glow: 'hover:neon-glow-pink'
        },
    ];

    return (
        <footer className="relative mt-20 overflow-hidden">
            {/* Vibrant Wave Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 via-purple-500/10 to-pink-500/10" />
            <div className="absolute inset-0">
                <svg className="absolute bottom-0 w-full" viewBox="0 0 1440 320" preserveAspectRatio="none">
                    <defs>
                        <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stopColor="rgb(0, 240, 255)" stopOpacity="0.3" />
                            <stop offset="50%" stopColor="rgb(191, 64, 255)" stopOpacity="0.3" />
                            <stop offset="100%" stopColor="rgb(255, 16, 240)" stopOpacity="0.3" />
                        </linearGradient>
                    </defs>
                    <motion.path
                        fill="url(#wave-gradient)"
                        d="M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,181.3C960,181,1056,235,1152,234.7C1248,235,1344,181,1392,154.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
                        animate={{
                            d: [
                                "M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,181.3C960,181,1056,235,1152,234.7C1248,235,1344,181,1392,154.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z",
                                "M0,160L48,170.7C96,181,192,203,288,192C384,181,480,139,576,138.7C672,139,768,181,864,186.7C960,192,1056,160,1152,154.7C1248,149,1344,171,1392,181.3L1440,192L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z",
                                "M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,181.3C960,181,1056,235,1152,234.7C1248,235,1344,181,1392,154.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
                            ]
                        }}
                        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
                    />
                </svg>
            </div>

            <div className="relative max-w-7xl mx-auto px-4 py-12">
                <ScrollReveal>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
                        <div>
                            <motion.div
                                whileHover={{ scale: 1.05 }}
                                className="mb-4"
                            >
                                <div className="flex items-center gap-2">
                                    <Sparkles className="w-6 h-6 text-cyan-400 animate-pulse" />
                                    <h3 className="text-2xl font-bold rainbow-text">Skyline Corps</h3>
                                </div>
                            </motion.div>
                            <p className="text-sm text-foreground/70 leading-relaxed">
                                Transforming digital visions into reality with <span className="text-primary font-semibold">innovative IT solutions</span> and cutting-edge technology.
                            </p>
                        </div>

                        <div>
                            <h4 className="font-bold mb-4 text-lg gradient-text">Quick Links</h4>
                            <ul className="space-y-2 text-sm">
                                {[
                                    { href: '/', label: 'Home' },
                                    { href: '/products', label: 'Products' },
                                    { href: '/about', label: 'About' },
                                    { href: '/contact', label: 'Contact' },
                                ].map((link) => (
                                    <motion.li
                                        key={link.href}
                                        whileHover={{ x: 5 }}
                                        transition={{ type: 'spring', stiffness: 300 }}
                                    >
                                        <Link
                                            href={link.href}
                                            className="text-foreground/70 hover:text-primary hover:font-semibold transition-all duration-300 flex items-center gap-2 group"
                                        >
                                            <span className="w-0 h-0.5 bg-primary group-hover:w-3 transition-all duration-300" />
                                            {link.label}
                                        </Link>
                                    </motion.li>
                                ))}
                            </ul>
                        </div>

                        <div>
                            <h4 className="font-bold mb-4 text-lg gradient-text">Legal</h4>
                            <ul className="space-y-2 text-sm">
                                {[
                                    { href: '#', label: 'Privacy Policy' },
                                    { href: '#', label: 'Terms of Service' },
                                    { href: '#', label: 'Cookie Policy' },
                                ].map((link) => (
                                    <motion.li
                                        key={link.label}
                                        whileHover={{ x: 5 }}
                                        transition={{ type: 'spring', stiffness: 300 }}
                                    >
                                        <Link
                                            href={link.href}
                                            className="text-foreground/70 hover:text-accent hover:font-semibold transition-all duration-300 flex items-center gap-2 group"
                                        >
                                            <span className="w-0 h-0.5 bg-accent group-hover:w-3 transition-all duration-300" />
                                            {link.label}
                                        </Link>
                                    </motion.li>
                                ))}
                            </ul>
                        </div>

                        <div>
                            <h4 className="font-bold mb-4 text-lg gradient-text">Connect</h4>
                            <div className="flex flex-wrap gap-3 mb-4">
                                {socialLinks.map((social) => (
                                    <motion.a
                                        key={social.label}
                                        href={social.href}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className={`p-3 rounded-full glass-vibrant ${social.color} ${social.glow} text-white transition-all duration-300 group`}
                                        aria-label={social.label}
                                        whileHover={{ scale: 1.15, rotate: 5 }}
                                        whileTap={{ scale: 0.95 }}
                                    >
                                        <social.icon className="w-5 h-5 group-hover:animate-wave" />
                                    </motion.a>
                                ))}
                            </div>
                            <div className="mt-4 text-sm text-foreground/70">
                                <p className="flex items-center gap-2 mb-1 hover:text-primary transition-colors">
                                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                                    </svg>
                                    <span>+62 819-3651-4430</span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className="border-t border-foreground/10 pt-8 text-center">
                        <motion.p
                            className="text-sm text-foreground/70 flex items-center justify-center gap-2 flex-wrap"
                            initial={{ opacity: 0 }}
                            whileInView={{ opacity: 1 }}
                            viewport={{ once: true }}
                        >
                            <span>&copy; {currentYear} Skyline Corps. Made with</span>
                            <Heart className="w-4 h-4 text-pink-500 animate-pulse fill-current" />
                            <span>and lots of</span>
                            <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
                        </motion.p>
                        <motion.p
                            className="text-xs text-foreground/50 mt-2"
                            initial={{ opacity: 0 }}
                            whileInView={{ opacity: 1 }}
                            viewport={{ once: true }}
                            transition={{ delay: 0.2 }}
                        >
                            All rights reserved.
                        </motion.p>
                    </div>
                </ScrollReveal>
            </div>
        </footer>
    );
}
