export interface PricingTier {
    price: string;
    label: string;
    features: string[];
}

export interface PricingTiers {
    basic: PricingTier;
    professional: PricingTier;
    enterprise: PricingTier;
}

export interface Product {
    id: string;
    _id?: string;
    name: string;
    description: string;
    price: string | number;
    pricingTiers?: PricingTiers;
    category: string;
    image: string;
    images: string[];
    rating: number;
    reviews: number;
    stock: number;
    featured: boolean;
    tags: string[];
    createdAt?: Date;
    updatedAt?: Date;
}

export interface User {
    _id: string;
    name: string;
    email: string;
    role: 'user' | 'admin';
    image?: string;
    createdAt: Date;
    updatedAt: Date;
}

export interface Message {
    _id: string;
    name: string;
    email: string;
    subject: string;
    message: string;
    read: boolean;
    createdAt: Date;
}

export interface Favorite {
    _id: string;
    userId: string;
    productId: string;
    createdAt: Date;
}

export interface TeamMember {
    id: string;
    name: string;
    role: string;
    bio: string;
    image: string;
    social: {
        twitter?: string;
        linkedin?: string;
        github?: string;
    };
}

export interface TimelineEvent {
    id: string;
    year: string;
    title: string;
    description: string;
}

export interface Feature {
    icon: string;
    title: string;
    description: string;
}

export interface Statistic {
    label: string;
    value: number;
    suffix: string;
    prefix?: string;
}
