import mongoose, { Schema, models } from 'mongoose';

export interface IProduct {
    _id: string;
    name: string;
    description: string;
    price: number;
    category: string;
    image: string;
    images: string[];
    rating: number;
    reviews: number;
    stock: number;
    featured: boolean;
    tags: string[];
    createdAt: Date;
    updatedAt: Date;
}

const productSchema = new Schema<IProduct>(
    {
        name: {
            type: String,
            required: [true, 'Product name is required'],
            trim: true,
        },
        description: {
            type: String,
            required: [true, 'Description is required'],
        },
        price: {
            type: Number,
            required: [true, 'Price is required'],
            min: 0,
        },
        category: {
            type: String,
            required: [true, 'Category is required'],
            enum: ['Electronics', 'Fashion', 'Home', 'Sports', 'Books', 'Toys', 'Food', 'Other'],
        },
        image: {
            type: String,
            required: true,
        },
        images: {
            type: [String],
            default: [],
        },
        rating: {
            type: Number,
            default: 0,
            min: 0,
            max: 5,
        },
        reviews: {
            type: Number,
            default: 0,
            min: 0,
        },
        stock: {
            type: Number,
            required: true,
            min: 0,
        },
        featured: {
            type: Boolean,
            default: false,
        },
        tags: {
            type: [String],
            default: [],
        },
    },
    {
        timestamps: true,
    }
);

const Product = models.Product || mongoose.model<IProduct>('Product', productSchema);

export default Product;
